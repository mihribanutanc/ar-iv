package com.identity.keycloak.util;

import com.identity.keycloak.config.IdentityConfig;
import com.identity.keycloak.model.User;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class UserIdentityUtils {
	private IdentityConfig config;

	@Autowired
	public UserIdentityUtils(IdentityConfig config) {
		this.config = config;
	}

}
