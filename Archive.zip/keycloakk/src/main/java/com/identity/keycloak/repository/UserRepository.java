package com.identity.keycloak.repository;

import com.identity.keycloak.model.User;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface UserRepository extends CassandraRepository<User,String> {

}
