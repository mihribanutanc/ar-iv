package com.identity.keycloak;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KeycloakIdentityApplication {

	public static void main(String[] args) {
		SpringApplication.run(KeycloakIdentityApplication.class, args);
	}

}
