package com.identity.keycloak.config;

import lombok.Getter;
import org.keycloak.OAuth2Constants;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.KeycloakBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;



@Configuration
public class IdentityConfig {

    @Getter
    @Value("${keycloak.realm}")
    private String realm;

    @Getter
    @Value("${keycloak.auth-server-url}")
    private String url;

    @Getter
    @Value("${keycloak.resource}")
    private String clientId;

    @Getter
    @Value("${keycloak.credentials.secret}")
    private String clientSecret;

    @Bean(name = {"KEYCLOAK_ADMIN_CLIENT"})
    @Primary
    public Keycloak keycloakAdminClient() {
        return KeycloakBuilder.builder()
                .serverUrl(this.url)
                .grantType(OAuth2Constants.CLIENT_CREDENTIALS)
                .realm(realm)
                .clientId(this.clientId)
                .clientSecret(this.clientSecret)
                .build();
    }
}
