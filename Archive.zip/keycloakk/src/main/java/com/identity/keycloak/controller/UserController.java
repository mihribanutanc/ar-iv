package com.identity.keycloak.controller;


import com.identity.keycloak.model.Group;
import com.identity.keycloak.model.JoinLeaveGroup;
import com.identity.keycloak.model.User;
import com.identity.keycloak.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/user")
public class UserController {

    @Autowired
    UserService userService;

    @PostMapping
    public ResponseEntity<User> cerateUser(@RequestBody User user){
        User userdb= userService.createUser(user);
        return ResponseEntity.ok(userdb);
    }

    @PutMapping
    public ResponseEntity<User> updateUser(@RequestBody User user){
        User userdb= userService.updateUser(user);
        return ResponseEntity.ok(userdb);
    }

    @GetMapping("/{username}")
    public ResponseEntity<User> getUser(@PathVariable("username") String username){
        return ResponseEntity.ok(userService.getUser(username));
    }

    @PostMapping("/join")
    public JoinLeaveGroup joinGroup(@RequestBody JoinLeaveGroup joinLeaveGroup){
       return userService.joinGroup(joinLeaveGroup);
    }

    @GetMapping("/group")
    public List<Group> getGroupId(){
        return userService.getAllGroups();
    }

    @GetMapping("{groupName}")
    public List<User> getGroupMembers(@PathVariable String groupName){
        return userService.getGroupMembers(groupName);
    }
}
