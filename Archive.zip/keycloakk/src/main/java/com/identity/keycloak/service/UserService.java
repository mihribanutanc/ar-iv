package com.identity.keycloak.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.identity.keycloak.config.IdentityConfig;
import com.identity.keycloak.model.Group;
import com.identity.keycloak.model.JoinLeaveGroup;
import com.identity.keycloak.model.User;
import com.identity.keycloak.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.GroupsResource;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.GroupRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.stereotype.Service;

import javax.ws.rs.core.Response;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@RequiredArgsConstructor
@Service
public class UserService {


    private final UserRepository userRepository;

    private final Keycloak keycloak;

    private final IdentityConfig identityConfig;

    public User  createUser(User user){

             try {
                 UserRepresentation userRepresentation = generateUserRepresentationObject(user);
                 RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
                 UsersResource usersResource = realmResource.users();
                 Response response = usersResource.create(userRepresentation);

             }catch (Exception e){
                 log.info("exception: {}",e);
             }
        return userRepository.save(user);
    }

    public User updateUser(User user) {
        RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
        UsersResource usersResource = realmResource.users();
        UserResource existingUserResource = usersResource.get(user.getId());

        UserRepresentation existingUser;
        try {
            existingUser = existingUserResource.toRepresentation();
        } catch (Exception exception) {
            log.info("exception: {}", exception);
        }


        UserRepresentation userRepresentationUpdate;
        try {
            userRepresentationUpdate = generateUserRepresentationUpdateObject(user);
            existingUserResource.update(userRepresentationUpdate);
            UserResource updatedUserResource = usersResource.get(user.getId());
            return generateUserObject(user.getId(), updatedUserResource.toRepresentation());
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    public User getUser(String username){
        RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
        UsersResource usersResource = realmResource.users();
        UserResource userResource = usersResource.get(username);
        UserRepresentation userRepresentation = userResource.toRepresentation();
        return generateUserObject(username, userRepresentation);
    }

    public List<Group> getAllGroups() {

            RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
            GroupsResource groupsResource = realmResource.groups();
            return groupsResource.groups().stream().map(value -> new Group(value.getId(), value.getName())).collect(Collectors.toList());

    }

    public List<User> getGroupMembers(String groupName) {
        try {
            RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
            GroupsResource groupsResource = realmResource.groups();
            List<UserRepresentation> userRepresentationList = groupsResource.group(groupName).members();

            List<User> keycloakUserList = new ArrayList<>();
            if (!userRepresentationList.isEmpty()) {
                keycloakUserList = userRepresentationList.stream().map(value -> generateUserObject(value.getId(), value)).collect(Collectors.toList());
            }
            return keycloakUserList;
        } catch (Exception exception) {
            throw new RuntimeException(exception.getMessage());
        }
    }

/*
    public JoinLeaveGroup deleteUser(JoinLeaveGroup leaveGroup){

      RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
      UsersResource usersResource = realmResource.users();

      UserResource existingUserResource = usersResource.get(leaveGroup.getKeycloakUserId());
      for (Group group : getAllGroups()) {
         existingUserResource.leaveGroup(group.getId());
      }

      User user = generateUserObject(leaveGroup.getKeycloakUserId(), existingUserResource.toRepresentation());
      userRepository.delete(user);
      return getUpdatedGroupsFromUser(usersResource,leaveGroup);
  }


 */

    public JoinLeaveGroup joinGroup(JoinLeaveGroup joinGroup) {

            RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
            UsersResource usersResource = realmResource.users();
            UserResource existingUserResource = usersResource.get(joinGroup.getKeycloakUserId());

                existingUserResource.joinGroup(joinGroup.getGroupId());

            return getUpdatedGroupsFromUser(usersResource, joinGroup);
        }

    public UserRepresentation generateUserRepresentationObject(User user) {
        UserRepresentation userRepresentation = new UserRepresentation();
        userRepresentation.setUsername(user.getUserName());
        userRepresentation.setEmail(user.getEmail());
        userRepresentation.setEnabled(Boolean.TRUE);
        userRepresentation.setEmailVerified(Boolean.TRUE);
        userRepresentation.setFirstName(user.getFirstName());
        userRepresentation.setLastName(user.getLastName());
        userRepresentation.setGroups(Arrays.asList("Bgroup"));
        userRepresentation.setAttributes(new HashMap<>());
        userRepresentation.getAttributes().put("userId", Collections.singletonList(user.getId()));
        List<CredentialRepresentation> credentials = new ArrayList<>();

        CredentialRepresentation credentialRepresentation = new CredentialRepresentation();
        credentialRepresentation.setType(CredentialRepresentation.PASSWORD);
        credentialRepresentation.setValue(user.getPassword());
        credentialRepresentation.setTemporary(false);
        credentials.add(credentialRepresentation);
        userRepresentation.setCredentials(credentials);
        return userRepresentation;
    }

    public static UserRepresentation generateUserRepresentationUpdateObject(User user) throws JsonProcessingException {
        UserRepresentation userRepresentationUpdate = new UserRepresentation();
        userRepresentationUpdate.setId(user.getId());
        userRepresentationUpdate.setUsername(user.getUserName());
        userRepresentationUpdate.setEmail(user.getEmail());
        userRepresentationUpdate.setEnabled(Boolean.TRUE);
        userRepresentationUpdate.setEmailVerified(Boolean.TRUE);
        userRepresentationUpdate.setFirstName(user.getFirstName());
        userRepresentationUpdate.setLastName(user.getLastName());
        userRepresentationUpdate.setAttributes(new HashMap<>());
        userRepresentationUpdate.getAttributes().put("userId", Collections.singletonList(user.getId()));

        return userRepresentationUpdate;
    }

    public static User generateUserObject(String keycloakUserId, UserRepresentation userRepresentation){
        User user = new User();
        try{
            user.setId(keycloakUserId);
            user.setUserName(userRepresentation.getUsername());
            user.setEmail(userRepresentation.getEmail());
            user.setFirstName(userRepresentation.getFirstName());
            user.setLastName(userRepresentation.getLastName());

        }catch (Exception exception){
            exception.printStackTrace();
        }
        return user;
    }

  private JoinLeaveGroup getUpdatedGroupsFromUser(UsersResource usersResource, JoinLeaveGroup joinLeaveGroup) {
      UserResource updatedUserResource = usersResource.get(joinLeaveGroup.getKeycloakUserId());
      List<GroupRepresentation> groupRepresentationList = updatedUserResource.groups();
      if (!groupRepresentationList.isEmpty()) {
          List<Group> updatedGroupList = groupRepresentationList.stream().map(value -> new Group(value.getId(), value.getName())).collect(Collectors.toList());
      }
      return joinLeaveGroup;
  }


}