package com.identity.keycloak.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

import java.io.Serializable;
import java.util.Map;

import static org.springframework.data.cassandra.core.cql.PrimaryKeyType.PARTITIONED;

@Data
@Table("users")
public class User implements Serializable {

    @PrimaryKeyColumn(name = "id",type = PARTITIONED)
    String id;

    @Column
    String userName;

    @Column
    String password;

    @Column
    String email;

    @Column
    String firstName;

    @Column
    String lastName;


}
