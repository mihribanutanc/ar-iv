update iot.userssss
set username='muhammet.dinç'
where id = 'string'