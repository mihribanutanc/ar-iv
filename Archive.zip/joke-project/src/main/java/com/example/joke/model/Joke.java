package com.example.joke.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "joke")
@Data
public class Joke {

	@Id
	@GeneratedValue(generator = "UUIDGenerator")
	@Column(name = "table_id")
	private UUID id;

	@JsonProperty("id")
	@Column(name = "joke_id")
	private int jokeId;

	@Column(name = "error")
	private boolean error;

	@Column(name = "language")
	private String language;

	@Enumerated(EnumType.STRING)
	@Column(name = "category")
	private JokeCategory category;

	@Column(name = "joke")
	private String joke;

	@Enumerated(EnumType.STRING)
	@Column(name = "type")
	private JokeType type;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "flag_id",foreignKey = @ForeignKey(name = "fk_joke_flags"))
	private Flag flags;

}
