package com.example.joke.model;

public enum JokeCategory {

	PROGRAMING("Programming"),
	MISCELLANEOUS("Miscellaneous"),
	DARK("Dark"),
	PUN("Pun"),
	SPOOKY("Spooky"),
	CHRISTMAS("Christmas");

	private String description;

	JokeCategory(String description){
		this.description=description;
	}

	public String getDescription(){
		return description;
	}

}
