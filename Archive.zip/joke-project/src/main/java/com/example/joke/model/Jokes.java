package com.example.joke.model;

import lombok.Data;

import java.util.List;

@Data
public class Jokes {

	List<Joke> jokes;

}
