package com.example.joke.model;

public enum JokeType {
	SINGLE("single"),TWOPART("twopart");

	private String descripton;

	JokeType(String descripton) {
		this.descripton = descripton;
	}

	public String getDescripton() {
		return descripton;
	}
}
