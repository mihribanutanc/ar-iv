package com.example.joke.repository;

import com.example.joke.model.Joke;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface JokeRepository extends JpaRepository<Joke, UUID> {

}
