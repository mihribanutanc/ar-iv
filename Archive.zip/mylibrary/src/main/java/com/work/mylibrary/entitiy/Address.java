package com.work.mylibrary.entitiy;


import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "address")
@Data
public class Address extends BaseEntity{
	private String city;
	private String district;
	private String street;

}
