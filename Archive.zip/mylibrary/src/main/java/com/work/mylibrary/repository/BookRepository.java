package com.work.mylibrary.repository;


import com.work.mylibrary.entitiy.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface BookRepository extends JpaRepository<Book, UUID> {

	List<Book> findAllByCategoryId(UUID categoryId);

	@Query("select b from Book b where b.user.id = :userId")
	List<Book> findAllUserBooks(@Param("userId") UUID userId);

	@Query("SELECT b FROM Book b  where b.user.id = :userId and upper(lower(b.name)) like upper(lower(concat( '%',:searchKey,'%') )) ")
	List<Book> findUserBooksByUserIdWithFilter(@Param("userId") UUID userId,@Param("searchKey") String searchKey);
}
