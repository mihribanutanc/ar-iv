package com.work.mylibrary.mapper;

import com.springboot.mylibrary.dto.CategoryDto;
import com.springboot.mylibrary.entitiy.Category;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface CategoryMapper {
	Category toEntity(CategoryDto categoryDto);
	CategoryDto toDto(Category category);
}
