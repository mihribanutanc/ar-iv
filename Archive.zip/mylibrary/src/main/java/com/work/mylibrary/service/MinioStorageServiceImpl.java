package com.work.mylibrary.service;

import io.minio.*;
import io.minio.errors.*;
import io.minio.messages.Item;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

@Slf4j
@Data
@RequiredArgsConstructor
@Service
public class MinioStorageServiceImpl {

	private final MinioClient minioClient;

	public void uploadFile(String bucketName, InputStream data, String filePath) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {

			PutObjectArgs args = PutObjectArgs.builder().object(filePath).stream(data, data.available(), -1)
					.bucket(bucketName).build();
			minioClient.putObject(args);
			log.info("File uploaded path [ {} ] to Minio", filePath);


	}

	public GetObjectResponse downloadFile(String bucketName, String objectName) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {

			GetObjectArgs objectArgs = GetObjectArgs.builder().object(objectName).bucket(bucketName).build();
			GetObjectResponse minioClientObject = minioClient.getObject(objectArgs);
			log.info("File downloaded path [ {} ] from Minio", objectName);
			return minioClientObject;

	}

	public void removeFile(String bucketName, StringBuilder filePath) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {

		Iterable<Result<Item>> listObjects = minioClient.listObjects(
				ListObjectsArgs.builder().bucket(bucketName).recursive(true).prefix(filePath.toString()).build());

		for (Result<Item> listObject : listObjects) {
			minioClient.removeObject(
					RemoveObjectArgs.builder().bucket(bucketName).object(listObject.get().objectName()).build());
		}
	}
}
