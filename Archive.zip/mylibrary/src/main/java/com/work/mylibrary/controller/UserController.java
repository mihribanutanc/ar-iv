package com.work.mylibrary.controller;

import com.springboot.mylibrary.api.UserApi;
import com.springboot.mylibrary.dto.UserDto;
import com.springboot.mylibrary.entitiy.User;
import com.springboot.mylibrary.mapper.UserMapper;
import com.springboot.mylibrary.service.UserServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;


@RestController
@RequiredArgsConstructor
public class UserController implements UserApi {

	private final UserServiceImpl userService;

	private final UserMapper userMapper;

	@Override
	public UserDto saveUser(UserDto userDto) {
		var user = userMapper.toEntity(userDto);

		return userMapper.toDto(userService.saveUser(user));

	}

	@Override
	public Page<UserDto> getUsers(Pageable pageable) {
		return userService.getUsers(pageable).map(userMapper::toDto);
	}

	@Override
	public UserDto getUserById(UUID id) {
		User user = userService.getUserById(id);
		return userMapper.toDto(user);
	}

	@Override
	public void deleteUser(UUID id) {
			userService.delete(id);
	}
}
