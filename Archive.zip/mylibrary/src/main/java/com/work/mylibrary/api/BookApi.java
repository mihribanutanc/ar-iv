package com.work.mylibrary.api;

import com.springboot.mylibrary.dto.BookDto;
import com.springboot.mylibrary.dto.BookResponseDto;
import com.springboot.mylibrary.dto.CategoryDto;
import com.springboot.mylibrary.entitiy.Category;
import com.springboot.mylibrary.exception.ExceptionResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;


@Tag(name = "Books",description = "Library services")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping(path = "/books")
public interface BookApi {

	@Operation(operationId = "saveBook", summary = "Save book")
	@ApiResponses(value= {
			@ApiResponse(responseCode = "200", description = "SUCCESS", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "201", description = "Created", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = ExceptionResponse.class))),
			@ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content(schema = @Schema(implementation = ExceptionResponse.class))),
			@ApiResponse(responseCode = "403", description = "Forbidden", content = @Content(schema = @Schema(implementation = ExceptionResponse.class))),
			@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = ExceptionResponse.class))),
			@ApiResponse(responseCode = "405", description = "Method Not Allowed", content = @Content(schema = @Schema(implementation = ExceptionResponse.class))),
			@ApiResponse(responseCode = "409", description = "Conflict", content = @Content(schema = @Schema(implementation = ExceptionResponse.class))),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = ExceptionResponse.class)))})
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	BookDto saveBook(@RequestBody BookDto bookDto);

	@Operation(operationId = "getBook", summary = "Get book ")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "SUCCESS", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "403", description = "Forbidden", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "405", description = "Method Not Allowed", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = BookDto.class)))})
	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	List<BookResponseDto> getBooks();

	@Operation(operationId = "getBookByCategory", summary = "Get book by category")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "SUCCESS", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "403", description = "Forbidden", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "405", description = "Method Not Allowed", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = BookDto.class)))})
	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	List<BookResponseDto> getBooksByCategory(UUID categoryId);

	@Operation(operationId = "getBookById", summary = "Get book by id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "SUCCESS", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = ExceptionResponse.class))),
			@ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content(schema = @Schema(implementation = ExceptionResponse.class))),
			@ApiResponse(responseCode = "403", description = "Forbidden", content = @Content(schema = @Schema(implementation = ExceptionResponse.class))),
			@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = ExceptionResponse.class))),
			@ApiResponse(responseCode = "405", description = "Method Not Allowed", content = @Content(schema = @Schema(implementation = ExceptionResponse.class))),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = ExceptionResponse.class)))})
	@GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	BookResponseDto getBookById(@PathVariable("id") UUID id);

	@Operation(operationId = "deleteBook", summary = "Delete book by id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "SUCCESS", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = Exception.class))),
			@ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content(schema = @Schema(implementation = Exception.class))),
			@ApiResponse(responseCode = "403", description = "Forbidden", content = @Content(schema = @Schema(implementation = Exception.class))),
			@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = Exception.class))),
			@ApiResponse(responseCode = "405", description = "Method Not Allowed", content = @Content(schema = @Schema(implementation = Exception.class))),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = Exception.class)))})
	@DeleteMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	void deleteBook(@PathVariable("id") UUID id);

	@Operation(operationId = "saveCategory", summary = "Save category")
	@ApiResponses(value= {
			@ApiResponse(responseCode = "200", description = "SUCCESS", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "201", description = "Created", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = Exception.class))),
			@ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content(schema = @Schema(implementation = Exception.class))),
			@ApiResponse(responseCode = "403", description = "Forbidden", content = @Content(schema = @Schema(implementation = Exception.class))),
			@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = Exception.class))),
			@ApiResponse(responseCode = "405", description = "Method Not Allowed", content = @Content(schema = @Schema(implementation = Exception.class))),
			@ApiResponse(responseCode = "409", description = "Conflict", content = @Content(schema = @Schema(implementation = Exception.class))),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = Exception.class)))})
	@PostMapping(value = "/category",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	CategoryDto saveCategory(@RequestBody CategoryDto category);

	@Operation(operationId = "saveCategory", summary = "Save category")
	@ApiResponses(value= {
			@ApiResponse(responseCode = "200", description = "SUCCESS", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "201", description = "Created", content = @Content(schema = @Schema(implementation = BookDto.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = Exception.class))),
			@ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content(schema = @Schema(implementation = Exception.class))),
			@ApiResponse(responseCode = "403", description = "Forbidden", content = @Content(schema = @Schema(implementation = Exception.class))),
			@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = Exception.class))),
			@ApiResponse(responseCode = "405", description = "Method Not Allowed", content = @Content(schema = @Schema(implementation = Exception.class))),
			@ApiResponse(responseCode = "409", description = "Conflict", content = @Content(schema = @Schema(implementation = Exception.class))),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = Exception.class)))})
	@GetMapping(value = "/categoryId",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	Category getCategory(@RequestParam UUID categoryId);


}
