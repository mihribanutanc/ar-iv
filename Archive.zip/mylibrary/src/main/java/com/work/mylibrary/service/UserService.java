package com.work.mylibrary.service;

import com.springboot.mylibrary.entitiy.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.UUID;

public interface UserService {

	 User saveUser(User user);

	 Page<User> getUsers(Pageable pageable);

	 User getUserById(UUID id);

	 void delete(UUID id);
}
