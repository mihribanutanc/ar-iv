package com.work.mylibrary.entitiy;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.work.mylibrary.enums.BookStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;


@Entity
@Table(name = "book")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Book extends BaseEntity{

	private String name;

	private String authorName;

	private int totalPage;

	private int lastPage;

	private String published;

	@Enumerated(value = EnumType.STRING)
	private BookStatus status;

	@ManyToOne
	@JoinColumn(name = "category_id")
	@JsonIgnore
	private Category category;

	@OneToOne
	@JoinColumn(name = "image_id")
	private Image image;

	@ManyToOne
	@JoinColumn(name = "user_id")
	@JsonIgnore
	private User user;
}
