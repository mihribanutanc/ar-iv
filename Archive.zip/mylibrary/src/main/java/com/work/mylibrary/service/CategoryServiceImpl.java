package com.work.mylibrary.service;

import com.springboot.mylibrary.entitiy.Category;
import com.springboot.mylibrary.repository.CategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class CategoryServiceImpl implements CategoryService{
	private final CategoryRepository categoryRepository;

	public Category getCategory(UUID categoryId){
		return categoryRepository.findById(categoryId).orElseThrow();
	}
	public Category saveCategory(Category category){
		return categoryRepository.save(category);
	}
}
