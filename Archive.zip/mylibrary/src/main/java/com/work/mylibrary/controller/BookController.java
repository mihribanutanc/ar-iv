package com.work.mylibrary.controller;

import com.springboot.mylibrary.api.BookApi;
import com.springboot.mylibrary.dto.BookDto;
import com.springboot.mylibrary.dto.BookResponseDto;
import com.springboot.mylibrary.dto.CategoryDto;
import com.springboot.mylibrary.entitiy.Book;
import com.springboot.mylibrary.entitiy.Category;
import com.springboot.mylibrary.mapper.BookMapper;
import com.springboot.mylibrary.mapper.CategoryMapper;
import com.springboot.mylibrary.service.BookServiceImpl;
import com.springboot.mylibrary.service.CategoryServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

@RestController
@RequiredArgsConstructor
public class BookController implements BookApi {

	private final BookServiceImpl bookService;

	private final CategoryServiceImpl categoryService;

	private final BookMapper bookMapper;

	private final CategoryMapper categoryMapper;


	@Override
	public BookDto saveBook(BookDto bookDto) {
		var book = bookMapper.toEntity(bookDto);
		return bookMapper.toDto(bookService.saveBook(book));
	}

	@Override
	public List<BookResponseDto> getBooks() {
		List<Book> bookList = bookService.getBookList();
		return bookMapper.toDtoList(bookList);
	}

	@Override
	public List<BookResponseDto> getBooksByCategory(UUID categoryId) {
		List<Book> booksByCategory = bookService.getBooksByCategory(categoryId);
		return bookMapper.toDtoList(booksByCategory);
	}

	@Override
	public BookResponseDto getBookById(UUID id) {
	var book = bookService.getBookById(id);
		return bookMapper.toResponseDto(book) ;
	}

	@Override
	public void deleteBook(UUID id) {
		bookService.deleteBook(id);
	}

	@Override
	public CategoryDto saveCategory(CategoryDto categoryDto) {
		Category category = categoryMapper.toEntity(categoryDto);
		return categoryMapper.toDto(categoryService.saveCategory(category));
	}

	@Override
	public Category getCategory(UUID categoryId) {
		return categoryService.getCategory(categoryId);
	}


}
