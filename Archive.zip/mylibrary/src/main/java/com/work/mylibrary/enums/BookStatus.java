package com.work.mylibrary.enums;

public enum BookStatus {
	READ,WILL_BE_READ,READING
}
