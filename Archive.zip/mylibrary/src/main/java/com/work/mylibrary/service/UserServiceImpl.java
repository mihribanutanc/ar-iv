package com.work.mylibrary.service;

import com.springboot.mylibrary.entitiy.User;
import com.springboot.mylibrary.mapper.AddressRepository;
import com.springboot.mylibrary.repository.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class UserServiceImpl implements UserService{

	private final UserRepository userRepository;

	private final AddressRepository addressRepository;

	public UserServiceImpl(UserRepository userRepository, AddressRepository addressRepository) {
		this.userRepository = userRepository;
		this.addressRepository = addressRepository;
	}

	public User saveUser(User user){
		return userRepository.save(user);
	}
	public Page<User> getUsers(Pageable pageable){
		Page<User> allUser = userRepository.findAll(pageable);
		return allUser;
	}

	public User getUserById(UUID id){
		return userRepository.findById(id).get();
	}

	public void delete(UUID id){
		userRepository.deleteById(id);
	}
}
