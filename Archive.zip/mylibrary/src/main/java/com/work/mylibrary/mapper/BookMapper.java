package com.work.mylibrary.mapper;


import com.work.mylibrary.dto.BookDto;
import com.work.mylibrary.dto.BookResponseDto;
import com.work.mylibrary.entitiy.Book;
import org.springframework.web.bind.annotation.Mapping;

import java.util.List;

@Mapper
public interface BookMapper {

	@Mapping(source = "categoryId" , target = "category.id")
	@Mapping(source = "userId" , target = "user.id")
	Book toEntity(BookDto bookDto);

	@Mapping(target = "userId" , source = "user.id")
	BookDto toDto(Book book);

	@Mapping(target = "userId" , source = "user.id")
	List<BookResponseDto> toDtoList(List<Book> book);

	@Mapping(target = "categoryName" , source = "category.name")
	BookResponseDto toResponseDto(Book book);
}
