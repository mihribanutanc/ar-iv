package com.work.mylibrary.exception;

import lombok.Data;
import org.springframework.http.HttpStatus;


@Data
public class LibraryException extends RuntimeException{
	private String message;
	private Object detail;
	private HttpStatus status;

	public LibraryException(HttpStatus errorCode, ExceptionMessages messages) {
		super(errorCode.name());
		this.status = errorCode;
		this.message = messages.getMessages();
		this.detail = null;
	}

	public LibraryException(ExceptionMessages ed) {
		super(ed.getMessages());
	}

	public LibraryException(ExceptionMessages ed, Object... args) {
		super(String.format(ed.getMessages(), args));
	}


	public LibraryException(HttpStatus errorCode, ExceptionMessages message, Object errorDetail) {
		super(errorCode.name());
		this.status = errorCode;
		this.message = message.getMessages();
		this.detail = errorDetail;
	}
}
