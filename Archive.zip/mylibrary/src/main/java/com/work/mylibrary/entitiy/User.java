package com.work.mylibrary.entitiy;


import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "userss")
@Data
public class User extends BaseEntity{

	private String userName;

	private String surname;

	private String phone;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "address_id")
	private Address address;

	@OneToMany(mappedBy = "user")
	List<Book> books;
}
