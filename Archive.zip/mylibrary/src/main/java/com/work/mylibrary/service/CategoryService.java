package com.work.mylibrary.service;

import com.springboot.mylibrary.entitiy.Category;

import java.util.UUID;

public interface CategoryService {

	 Category getCategory(UUID categoryId);

	 Category saveCategory(Category category);
}
