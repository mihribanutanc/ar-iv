package com.work.mylibrary.dto;

import lombok.Data;

import java.util.UUID;

@Data
public class BookDto {

	private String name;

	private String authorName;

	private int totalPage;

	private int lastPage;

	private String published;

	private String status;

	private UUID categoryId;

	private UUID userId;
}
