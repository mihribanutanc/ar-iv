package com.work.mylibrary.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDateTime;
import java.util.List;


@Slf4j
@RestControllerAdvice
public class LibraryExceptionHandler extends ResponseEntityExceptionHandler {


	public ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException exception, HttpHeaders headers, HttpStatus httpStatus, WebRequest webRequest) {

		List<String> errors = exception.getBindingResult().getFieldErrors().stream().map(
				error -> error.getField() + ":" + error.getDefaultMessage()
		).toList();

		ExceptionResponse exceptionResponse = ExceptionResponse.builder()
				.timestamp(LocalDateTime.now())
				.status(httpStatus.value())
				.message(httpStatus.name())
				.path(webRequest.getContextPath())
				//.detail(exception.getMessage())
				.detail(errors.toString())
				.build();

		return new ResponseEntity<>(exceptionResponse,httpStatus);
	}

	@ExceptionHandler({LibraryException.class})
	ResponseEntity<ExceptionResponse> handleLibraryException(LibraryException exception,WebRequest webRequest){

		ExceptionResponse exceptionResponse = ExceptionResponse.builder()
				.timestamp(LocalDateTime.now())
				.status(exception.getStatus().value())
				.message(exception.getMessage())
				.path(webRequest.getContextPath())
				//.detail(exception.getMessage())
				.detail(exception.getDetail().toString())
				.build();

		return new ResponseEntity<>(exceptionResponse,exception.getStatus());
	}

	@ExceptionHandler({Exception.class})
	ResponseEntity<ExceptionResponse> handleGenericException(Exception exception,HttpStatus status ,WebRequest webRequest){

		ExceptionResponse exceptionResponse = ExceptionResponse.builder()
				.timestamp(LocalDateTime.now())
				.status(status.value())
				.message(status.name())
				.path(webRequest.getContextPath())
				//.detail(exception.getMessage())
				.detail(exception.getMessage())
				.build();

		return new ResponseEntity<>(exceptionResponse,status);
	}
}
