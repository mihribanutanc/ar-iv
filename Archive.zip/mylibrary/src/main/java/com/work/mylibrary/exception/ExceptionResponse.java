package com.work.mylibrary.exception;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Builder
@Data
public class ExceptionResponse {

	private String message;
	private String detail;
	private int status;
	private LocalDateTime timestamp;
	private String path;

}
