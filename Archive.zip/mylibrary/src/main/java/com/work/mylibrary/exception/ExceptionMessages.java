package com.work.mylibrary.exception;

public enum ExceptionMessages {

	USER_NOT_FOUND("User not found for this id, %s");

	private String messages;

	ExceptionMessages(String messages) {
		this.messages = messages;
	}

	public String getMessages() {
		return messages;
	}
}
