package com.work.mylibrary.service;

import com.work.mylibrary.entitiy.Book;

import java.util.List;
import java.util.UUID;

public interface BookService {

	 Book saveBook(Book book);

	 Book getBookById(UUID bookId);

	 List<Book> getBooksByCategory(UUID categoryId);

	 List<Book> getBookList();

	 void deleteBook(UUID bookId);
}
