package com.work.mylibrary.service;

import com.work.mylibrary.entitiy.Book;
import com.work.mylibrary.exception.ExceptionMessages;
import com.work.mylibrary.exception.LibraryException;
import com.work.mylibrary.repository.BookRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class BookServiceImpl implements BookService{

	private final BookRepository bookRepository;

	private final CategoryServiceImpl categoryService;

	public Book saveBook(Book book){

		return bookRepository.save(book);
	}

	public Book getBookById(UUID bookId) {


		try {
			Optional<Book> byId = bookRepository.findById(bookId);
			return byId.get();
		} catch (Exception exception) {
			throw new LibraryException(ExceptionMessages.USER_NOT_FOUND,bookId);
		}

	}

	public List<Book> getBooksByCategory(UUID categoryId){
		return bookRepository.findAllByCategoryId(categoryId);
	}

	public List<Book> getBookList(){
		return bookRepository.findAll();
	}

	public void deleteBook(UUID bookId){
		bookRepository.deleteById(bookId);
	}

}
