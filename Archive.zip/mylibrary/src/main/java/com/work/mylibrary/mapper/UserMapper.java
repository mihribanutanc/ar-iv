package com.work.mylibrary.mapper;

import com.springboot.mylibrary.dto.UserDto;
import com.springboot.mylibrary.entitiy.User;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface UserMapper {

	@Mapping(source = "address.id", target = "addressId")
	UserDto toDto(User user);

	@Mapping(source = "addressId", target = "address.id")
	User toEntity(UserDto userDto);
}
