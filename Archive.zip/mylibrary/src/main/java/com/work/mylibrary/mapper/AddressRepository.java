package com.work.mylibrary.mapper;

import com.springboot.mylibrary.entitiy.Address;
import com.work.mylibrary.entitiy.Address;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface AddressRepository extends JpaRepository<Address, UUID> {
}
