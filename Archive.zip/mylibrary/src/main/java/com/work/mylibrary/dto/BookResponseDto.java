package com.work.mylibrary.dto;

import lombok.Data;

@Data
public class BookResponseDto {
	private String name;

	private String authorName;

	private int totalPage;

	private int lastPage;

	private String published;

	private String status;

	private String categoryName;

}
