package com.work.mylibrary.entitiy;


import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;

@Entity
@Table(name = "category")
@Data
public class Category extends BaseEntity{
	private String name;

	@OneToMany(mappedBy = "category")
	private List<Book> books;
}
