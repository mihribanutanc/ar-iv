package com.work.mylibrary.dto;

import lombok.Data;

@Data
public class CategoryDto {
	private String name;
}
