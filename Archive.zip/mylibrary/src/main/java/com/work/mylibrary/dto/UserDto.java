package com.work.mylibrary.dto;

import lombok.Data;

import java.util.UUID;

@Data
public class UserDto {

	private String userName;

	private String surname;

	private String phone;

	private UUID addressId;

}

