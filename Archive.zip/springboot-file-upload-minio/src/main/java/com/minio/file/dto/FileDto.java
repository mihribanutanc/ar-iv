package com.minio.file.dto;

public class FileDto {

}
