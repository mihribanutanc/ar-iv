package com.minio.file.service;

import com.minio.file.config.MinioProperties;
import com.minio.file.util.FilePathUtil;
import io.minio.errors.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

@Service
@RequiredArgsConstructor
@Slf4j
public class FileServiceImpl implements FileService {

	private final MinioProperties minioProperties;

	private final MinioStorageService minioStorageService;
	@Override
	public void upload(String pathKey, MultipartFile[] files) throws IOException, ServerException, InsufficientDataException, ErrorResponseException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
		String path = FilePathUtil.filePath(pathKey).toString();
		for (MultipartFile file : files) {
			minioStorageService.uploadFile(minioProperties.getBucket(), file.getInputStream(),path);
		}
	}
	@Override
	public void removeArchiveDocument(String pathKey, String bucketName) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
		String path = FilePathUtil.filePath(pathKey).toString();
		minioStorageService.removeFile(bucketName, new StringBuilder(path));
	}
}
