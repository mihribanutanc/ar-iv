package com.minio.file.service;

import io.minio.GetObjectResponse;
import io.minio.errors.*;

import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public interface MinioStorageService {
	void uploadFile(String bucketName, InputStream data, String filePath)
			throws InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException,
			InvalidKeyException, InvalidResponseException, XmlParserException, InternalException, ServerException;

	GetObjectResponse downloadFile(String bucketName, String objectName)
			throws InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException,
			InvalidKeyException, InvalidResponseException, XmlParserException, InternalException, ServerException;

	void removeFile(String bucketName, StringBuilder filePath) throws ErrorResponseException, InsufficientDataException,
			InternalException, InvalidKeyException, InvalidResponseException,
			IOException, NoSuchAlgorithmException, ServerException, XmlParserException;

}
