package com.minio.file.service;

import io.minio.errors.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public interface FileService {
	void upload(String pathKey, MultipartFile[] files)
			throws IOException, ServerException, InsufficientDataException, ErrorResponseException,
			NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException,
			InternalException;

	void removeArchiveDocument(String pathKey, String bucketName) throws ServerException, InsufficientDataException,
			ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException,
			InvalidResponseException, XmlParserException, InternalException;
}
