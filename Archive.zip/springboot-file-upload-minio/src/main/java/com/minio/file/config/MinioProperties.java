package com.minio.file.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "app.minio")
public class MinioProperties {

	@Value("${app.minio.host}")
	private String hostt;

	@Value("${app.minio.access-key}")
	private String accessKey;

	@Value("${app.minio.secret-key}")
	private String secretKey;

	@Value("${app.minio.bucket}")
	private String bucket;

}
