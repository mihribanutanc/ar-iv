package com.minio.file.repository;

import com.minio.file.entity.ProjectFile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FileRepository extends JpaRepository<ProjectFile,Long> {

}
