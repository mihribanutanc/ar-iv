package com.minio.file.util;

public class FilePathUtil {

	public static StringBuilder filePath(String key){

		StringBuilder filePath = new StringBuilder(key.substring(0, 2)).append("/")
				.append(key.substring(2, 4)).append("/")
				.append(key.substring(4, 6)).append(key).append("/");
		return filePath;
	}
}
