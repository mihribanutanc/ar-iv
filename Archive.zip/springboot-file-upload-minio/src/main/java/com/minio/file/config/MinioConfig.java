package com.minio.file.config;

import io.minio.MinioClient;
import lombok.AllArgsConstructor;
import okhttp3.OkHttpClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.TimeUnit;

@Configuration(proxyBeanMethods = false)
@AllArgsConstructor
public class MinioConfig {

	private final MinioProperties minioProperties;

	@Bean
	public MinioClient generateMinioClient() {
		try {
			OkHttpClient httpClient = new OkHttpClient.Builder()
					.connectTimeout(10, TimeUnit.MINUTES)
					.writeTimeout(10, TimeUnit.MINUTES)
					.readTimeout(30, TimeUnit.MINUTES)
					.build();
			MinioClient client = MinioClient.builder()
					.endpoint(minioProperties.getHostt())
					.httpClient(httpClient)
					.credentials(minioProperties.getAccessKey(), minioProperties.getSecretKey())
					.build();
			return client;
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}


}
