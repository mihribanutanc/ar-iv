# USER-IDENTITY-MANAGEMENT

User Identity Management


#### Java project run args


| ARG             | Description                 |
|-------------------|----------|
| PORT | Application server port |
| KEYCLOAK_HOST | Keycloak  hostname |
| KEYCLOAK_CLINET_ID   | Keycloak username   |
| KEYCLOAK_CLINET_SECRET  | Keycloak password  |
| DB_HOST   | Database hostname  |
| DB_USERNAME  | Database username  |
| DB_PASSWORD  | Database password  |

#### Installation / Make JAR

```bash
mvn clean install
