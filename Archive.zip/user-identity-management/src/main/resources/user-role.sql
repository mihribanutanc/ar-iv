INSERT INTO public.roles
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15e96ae2-2608-4655-0001-fd56c70fd603', NULL, NULL, NULL, NULL, NULL, 0, 'portalAdmin', 'Portal Admin', 1);
INSERT INTO public.roles
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96ae2-2608-4655-0002-fd56c70fd603', NULL, NULL, NULL, NULL, NULL, 0, 'documentAdmin', 'Document Admin', 1);
INSERT INTO public.roles
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96a12-2608-4655-0003-fd56c70fd603', NULL, NULL, NULL, NULL, NULL, 0, 'documentViewer', 'Document Viewer', 1);
INSERT INTO public.roles
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96a13-2608-4655-0004-fd56c70fd603', NULL, NULL, NULL, NULL, NULL, 0, 'user', 'User', 1);
INSERT INTO public.roles
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96f13-2608-4655-0005-fd56c70fd603', NULL, NULL, NULL, NULL, NULL, 0, 'integrationAdmin', 'Integration Admin', 1);
INSERT INTO public.roles
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96f13-2608-4655-0006-fd56c70fd613', NULL, NULL, NULL, NULL, NULL, 0, 'systemAdmin', 'System Admin', 1);



INSERT INTO public."privileges"
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96ae2-2608-4655-0007-fd56c70fd603', NULL, NULL, NULL, NULL, NULL, 0, 'createDocument', 'Create Document', 1);
INSERT INTO public."privileges"
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96a32-2608-4655-0008-fd56c70fd603', NULL, NULL, NULL, NULL, NULL, 0, 'signDocument', 'Sign Document', 1);
INSERT INTO public."privileges"
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96a32-2608-4655-0009-f156c70fd603', NULL, NULL, NULL, NULL, NULL, 0, 'sendDocument', 'Send Document', 1);
INSERT INTO public."privileges"
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96a32-2608-4655-0010-f156c71fd603', NULL, NULL, NULL, NULL, NULL, 0, 'viewerIncomingDocument', 'Viewer Incoming Document', 1);
INSERT INTO public."privileges"
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96a32-2608-4655-0011-f156c71fd603', NULL, NULL, NULL, NULL, NULL, 0, 'integration', 'Integration', 1);
INSERT INTO public."privileges"
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96a32-2608-4655-0012-f156c71fd604', NULL, NULL, NULL, NULL, NULL, 0, 'roleManagment', 'Role Managment', 1);
INSERT INTO public."privileges"
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96a32-2608-4655-0013-f156c71fd604', NULL, NULL, NULL, NULL, NULL, 0, 'userManagment', 'User Managment', 1);


INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0014-0000070fd603', NULL, NULL, NULL, NULL, NULL, 0, (select id from privileges where code='createDocument') , (select id from roles where code='portalAdmin'));
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0015-0000070fd604', NULL, NULL, NULL, NULL, NULL, 0, (select id from privileges where code='signDocument') , (select id from roles where code='portalAdmin'));
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0016-0000070fd605', NULL, NULL, NULL, NULL, NULL, 0,  (select id from privileges where code='sendDocument') , (select id from roles where code='portalAdmin'));
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0017-0000070fd606', NULL, NULL, NULL, NULL, NULL, 0, (select id from privileges where code='viewerIncomingDocument') , (select id from roles where code='portalAdmin'));
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0018-0000070fd607', NULL, NULL, NULL, NULL, NULL, 0,  (select id from privileges where code='integration') , (select id from roles where code='portalAdmin'));
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0019-0000070fd608', NULL, NULL, NULL, NULL, NULL, 0,  (select id from privileges where code='roleManagment') , (select id from roles where code='portalAdmin'));
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0020-0000070fd609', NULL, NULL, NULL, NULL, NULL, 0,  (select id from privileges where code='userManagment') , (select id from roles where code='portalAdmin'));



INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0021-0000070fd603', NULL, NULL, NULL, NULL, NULL, 0, (select id from privileges where code='createDocument') , (select id from roles where code='documentAdmin'));
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0022-0000070fd604', NULL, NULL, NULL, NULL, NULL, 0, (select id from privileges where code='signDocument') , (select id from roles where code='documentAdmin'));
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0023-0000070fd605', NULL, NULL, NULL, NULL, NULL, 0,  (select id from privileges where code='sendDocument') , (select id from roles where code='documentAdmin'));
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0024-0000070fd606', NULL, NULL, NULL, NULL, NULL, 0, (select id from privileges where code='viewerIncomingDocument') , (select id from roles where code='documentAdmin'));



INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0025-0000070fd603', NULL, NULL, NULL, NULL, NULL, 0, (select id from privileges where code='createDocument') , (select id from roles where code='documentViewer'));
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0026-0000070fd604', NULL, NULL, NULL, NULL, NULL, 0, (select id from privileges where code='signDocument') , (select id from roles where code='documentViewer'));
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0028-0000070fd606', NULL, NULL, NULL, NULL, NULL, 0, (select id from privileges where code='viewerIncomingDocument') , (select id from roles where code='documentViewer'));


INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0032-0000070fd606', NULL, NULL, NULL, NULL, NULL, 0, (select id from privileges where code='integration') , (select id from roles where code='integrationAdmin'));


