
CREATE TABLE public."privileges" (
	id varchar(255) NOT NULL,
	"version" int8 NOT NULL,
	code varchar(255) NULL,
	description varchar(255) NULL,
	status int4 NULL,
    cdate timestamp NULL,
	cuser_id varchar(255) NULL,
	deleted_date timestamp NULL,
	udate timestamp NULL,
	uuser_id varchar(255) NULL,
	CONSTRAINT privileges_pkey PRIMARY KEY (id)
);
CREATE INDEX privileges_code_idx ON public.privileges USING btree (code);


CREATE TABLE public.roles (
	id varchar(255) NOT NULL,
	"version" int8 NOT NULL,
	code varchar(255) NULL,
	description varchar(255) NULL,
	status int4 NULL,
	assignable bool NULL,
    cdate timestamp NULL,
	cuser_id varchar(255) NULL,
	deleted_date timestamp NULL,
	udate timestamp NULL,
	uuser_id varchar(255) NULL,
	CONSTRAINT roles_pkey PRIMARY KEY (id)
);
CREATE INDEX roles_code_idx ON public.roles USING btree (code);


CREATE TABLE public.role_privileges (
	id varchar(255) NOT NULL,
	"version" int8 NOT NULL,
	privileges_id varchar(255) NULL,
	role_id varchar(255) NULL,
    cdate timestamp NULL,
	cuser_id varchar(255) NULL,
	deleted_date timestamp NULL,
	udate timestamp NULL,
	uuser_id varchar(255) NULL,
	CONSTRAINT role_privileges_pkey PRIMARY KEY (id)
);
ALTER TABLE public.role_privileges ADD CONSTRAINT fk1ogn163i7q15fin6apx17xykc FOREIGN KEY (privileges_id) REFERENCES public."privileges"(id);
ALTER TABLE public.role_privileges ADD CONSTRAINT fkddceebgln19s0c4tjwj01v1ou FOREIGN KEY (role_id) REFERENCES public.roles(id);



CREATE TABLE public.user_privileges (
	id varchar(255) NOT NULL,
	"version" int8 NOT NULL,
	unit_id varchar(255) NULL,
	unit_code varchar(255) NULL,
	user_id varchar(255) NULL,
	privilege_id varchar(255) NULL,
    cdate timestamp NULL,
	cuser_id varchar(255) NULL,
	deleted_date timestamp NULL,
	udate timestamp NULL,
	uuser_id varchar(255) NULL,
	CONSTRAINT user_privileges_pkey PRIMARY KEY (id)
);
ALTER TABLE public.user_privileges ADD CONSTRAINT fk8ht5860cyq8fsdbceqwnq517e FOREIGN KEY (privilege_id) REFERENCES public."privileges"(id);


CREATE TABLE public.user_role (
	id varchar(255) NOT NULL,
	"version" int8 NOT NULL,
	is_master bool NULL,
	remove_able bool NULL,
	unit_id varchar(255) NULL,
	unit_code varchar(255) NULL,
	user_id varchar(255) NULL,
	role_id varchar(255) NULL,
	active int4 NULL,
    cdate timestamp NULL,
	cuser_id varchar(255) NULL,
	deleted_date timestamp NULL,
	udate timestamp NULL,
	uuser_id varchar(255) NULL,
	CONSTRAINT user_role_pkey PRIMARY KEY (id)
);
ALTER TABLE public.user_role ADD CONSTRAINT fkt7e7djp752sqn6w22i6ocqy6q FOREIGN KEY (role_id) REFERENCES public.roles(id);


INSERT INTO public."privileges"
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96ae2-2608-4655-0007-fd56c70fd603', NULL, NULL, NULL, NULL, NULL, 0, 'createDocument', 'Create Document', 1);
INSERT INTO public."privileges"
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96a32-2608-4655-0008-fd56c70fd603', NULL, NULL, NULL, NULL, NULL, 0, 'signDocument', 'Sign Document', 1);
INSERT INTO public."privileges"
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96a32-2608-4655-0009-f156c70fd603', NULL, NULL, NULL, NULL, NULL, 0, 'sendDocument', 'Send Document', 1);
INSERT INTO public."privileges"
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96a32-2608-4655-0010-f156c71fd603', NULL, NULL, NULL, NULL, NULL, 0, 'viewerIncomingDocument', 'Viewer Incoming Document', 1);
INSERT INTO public."privileges"
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96a32-2608-4655-0011-f156c71fd603', NULL, NULL, NULL, NULL, NULL, 0, 'integration', 'Integration', 1);
INSERT INTO public."privileges"
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96a32-2608-4655-0012-f156c71fd604', NULL, NULL, NULL, NULL, NULL, 0, 'roleManagment', 'Role Managment', 1);
INSERT INTO public."privileges"
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status)
VALUES('15f96a32-2608-4655-0013-f156c71fd604', NULL, NULL, NULL, NULL, NULL, 0, 'userManagment', 'User Managment', 1);



INSERT INTO public.roles
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status, assignable)
VALUES('15f96f13-2608-4655-0006-fd56c70fd613', NULL, NULL, NULL, NULL, NULL, 0, 'systemAdmin', 'System Admin', 1, NULL);
INSERT INTO public.roles
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status, assignable)
VALUES('15f96ae2-2608-4655-0002-fd56c70fd603', NULL, NULL, NULL, NULL, NULL, 0, 'documentAdmin', 'Document Admin', 1, true);
INSERT INTO public.roles
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status, assignable)
VALUES('15f96a12-2608-4655-0003-fd56c70fd603', NULL, NULL, NULL, NULL, NULL, 0, 'documentViewer', 'Document Viewer', 1, true);
INSERT INTO public.roles
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status, assignable)
VALUES('15f96a13-2608-4655-0004-fd56c70fd603', NULL, NULL, NULL, NULL, NULL, 0, 'user', 'User', 1, true);
INSERT INTO public.roles
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status, assignable)
VALUES('15f96f13-2608-4655-0005-fd56c70fd603', NULL, NULL, NULL, NULL, NULL, 0, 'integrationAdmin', 'Integration Admin', 1, true);
INSERT INTO public.roles
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", code, description, status, assignable)
VALUES('15e96ae2-2608-4655-0001-fd56c70fd603', NULL, NULL, NULL, NULL, NULL, 0, 'portalAdmin', 'Portal Admin', 1, true);


INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0014-0000070fd603', NULL, NULL, NULL, NULL, NULL, 0, '15f96ae2-2608-4655-0007-fd56c70fd603', '15e96ae2-2608-4655-0001-fd56c70fd603');
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0015-0000070fd604', NULL, NULL, NULL, NULL, NULL, 0, '15f96a32-2608-4655-0008-fd56c70fd603', '15e96ae2-2608-4655-0001-fd56c70fd603');
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0016-0000070fd605', NULL, NULL, NULL, NULL, NULL, 0, '15f96a32-2608-4655-0009-f156c70fd603', '15e96ae2-2608-4655-0001-fd56c70fd603');
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0017-0000070fd606', NULL, NULL, NULL, NULL, NULL, 0, '15f96a32-2608-4655-0010-f156c71fd603', '15e96ae2-2608-4655-0001-fd56c70fd603');
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0018-0000070fd607', NULL, NULL, NULL, NULL, NULL, 0, '15f96a32-2608-4655-0011-f156c71fd603', '15e96ae2-2608-4655-0001-fd56c70fd603');
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0019-0000070fd608', NULL, NULL, NULL, NULL, NULL, 0, '15f96a32-2608-4655-0012-f156c71fd604', '15e96ae2-2608-4655-0001-fd56c70fd603');
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0020-0000070fd609', NULL, NULL, NULL, NULL, NULL, 0, '15f96a32-2608-4655-0013-f156c71fd604', '15e96ae2-2608-4655-0001-fd56c70fd603');
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0021-0000070fd603', NULL, NULL, NULL, NULL, NULL, 0, '15f96ae2-2608-4655-0007-fd56c70fd603', '15f96ae2-2608-4655-0002-fd56c70fd603');
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0022-0000070fd604', NULL, NULL, NULL, NULL, NULL, 0, '15f96a32-2608-4655-0008-fd56c70fd603', '15f96ae2-2608-4655-0002-fd56c70fd603');
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0023-0000070fd605', NULL, NULL, NULL, NULL, NULL, 0, '15f96a32-2608-4655-0009-f156c70fd603', '15f96ae2-2608-4655-0002-fd56c70fd603');
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0024-0000070fd606', NULL, NULL, NULL, NULL, NULL, 0, '15f96a32-2608-4655-0010-f156c71fd603', '15f96ae2-2608-4655-0002-fd56c70fd603');
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0025-0000070fd603', NULL, NULL, NULL, NULL, NULL, 0, '15f96ae2-2608-4655-0007-fd56c70fd603', '15f96a12-2608-4655-0003-fd56c70fd603');
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0026-0000070fd604', NULL, NULL, NULL, NULL, NULL, 0, '15f96a32-2608-4655-0008-fd56c70fd603', '15f96a12-2608-4655-0003-fd56c70fd603');
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0028-0000070fd606', NULL, NULL, NULL, NULL, NULL, 0, '15f96a32-2608-4655-0010-f156c71fd603', '15f96a12-2608-4655-0003-fd56c70fd603');
INSERT INTO public.role_privileges
(id, cdate, cuser_id, deleted_date, udate, uuser_id, "version", privileges_id, role_id)
VALUES('15e96ae2-2608-4655-0032-0000070fd606', NULL, NULL, NULL, NULL, NULL, 0, '15f96a32-2608-4655-0011-f156c71fd603', '15f96f13-2608-4655-0005-fd56c70fd603');
