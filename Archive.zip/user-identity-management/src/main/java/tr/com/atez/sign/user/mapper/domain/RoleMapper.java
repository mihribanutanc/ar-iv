package tr.com.atez.sign.user.mapper.domain;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.util.CollectionUtils;
import tr.com.atez.sign.user.domain.Privileges;
import tr.com.atez.sign.user.domain.Role;
import tr.com.atez.sign.user.entity.PrivilegesEntity;
import tr.com.atez.sign.user.entity.RoleEntity;
import tr.com.atez.sign.user.entity.RolePrivilegesEntity;
import tr.com.atez.sign.user.mapper.domain.base.BaseMapper;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Abdulkerim ATİK
 */
@Mapper(componentModel = "spring")
public interface RoleMapper extends BaseMapper<RoleEntity, Role> {


    @Mapping(source = "rolePrivileges", target = "privileges", qualifiedByName = "convertRolePrivilegesToPrivileges")
    @Mapping(source = "rolePrivileges", target = "rolePrivileges", qualifiedByName = "convertRolePrivilegesToRolePrivileges")
    Role toDomainObject(RoleEntity entity);

    Privileges toPrivilegesDomain(PrivilegesEntity privileges);


    @Named("convertRolePrivilegesToPrivileges")
    default List<String> convertRolePrivilegesToPrivileges(List<RolePrivilegesEntity> rolePrivilegesEntities) {
        if (CollectionUtils.isEmpty(rolePrivilegesEntities)) {
            return List.of();
        }
        return rolePrivilegesEntities.stream().map(f -> f.getPrivileges().getCode()).collect(Collectors.toList());
    }


    @Named("convertRolePrivilegesToRolePrivileges")
    default List<Privileges> convertRolePrivilegesToRolePrivileges(List<RolePrivilegesEntity> rolePrivilegesEntities) {
        if (CollectionUtils.isEmpty(rolePrivilegesEntities)) {
            return List.of();
        }
        List<PrivilegesEntity> privileges = rolePrivilegesEntities.stream().map(f -> f.getPrivileges()).collect(Collectors.toList());
        List<Privileges> privilegesDomain = new ArrayList<>();
        privileges.forEach(f -> {
            if(Boolean.TRUE.equals(f.getIsAssignable())){
                privilegesDomain.add(toPrivilegesDomain(f));
            }
        });
        return privilegesDomain;
    }
}
