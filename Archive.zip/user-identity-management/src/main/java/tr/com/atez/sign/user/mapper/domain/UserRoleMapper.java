package tr.com.atez.sign.user.mapper.domain;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.util.CollectionUtils;
import tr.com.atez.sign.user.domain.UserRole;
import tr.com.atez.sign.user.entity.RolePrivilegesEntity;
import tr.com.atez.sign.user.entity.UserRoleEntity;
import tr.com.atez.sign.user.mapper.domain.base.BaseMapper;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Abdulkerim ATİK
 */
@Mapper(componentModel = "spring")
public interface UserRoleMapper extends BaseMapper<UserRoleEntity, UserRole> {

    @Mapping(source = "role.rolePrivileges", target = "privileges", qualifiedByName = "convertRolePrivilegesToPrivileges")
    UserRole toDomainObject(UserRoleEntity entity);

    @Named("convertRolePrivilegesToPrivileges")
    default List<String> convertRolePrivilegesToPrivileges(List<RolePrivilegesEntity> rolePrivilegesEntities) {
        if (CollectionUtils.isEmpty(rolePrivilegesEntities)) {
            return List.of();
        }
        return rolePrivilegesEntities.stream().map(f -> f.getPrivileges().getCode()).collect(Collectors.toList());
    }


}
