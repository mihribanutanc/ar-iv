package tr.com.atez.sign.user.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import javax.persistence.*;

/**
 * @author Abdulkerim ATİK
 */

@SQLDelete(sql = "UPDATE RolePrivileges SET DELETED_AT = CURRENT_TIMESTAMP WHERE id =? and version =? ")
@Where(clause = "DELETED_DATE is null")
@Entity(name = "RolePrivileges")
@Table(name = "ROLE_PRIVILEGES")
@Data
@EqualsAndHashCode(callSuper = false)
@ToString(callSuper = true, includeFieldNames = true)
public class RolePrivilegesEntity extends BaseEntity {

    @ManyToOne
    @JoinColumn(name = "PRIVILEGES_ID")
    private PrivilegesEntity privileges;

    @ManyToOne
    @JoinColumn(name = "ROLE_ID")
    private RoleEntity roles;
}
