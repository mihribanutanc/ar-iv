package tr.com.atez.sign.user.service;

import org.apache.commons.lang3.ObjectUtils;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.*;
import org.keycloak.representations.idm.GroupRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import tr.com.atez.sign.common.exception.SignException;
import tr.com.atez.sign.user.config.IdentityConfig;
import tr.com.atez.sign.user.domain.Group;
import tr.com.atez.sign.user.domain.JoinLeaveGroup;
import tr.com.atez.sign.user.domain.KeycloakUser;
import tr.com.atez.sign.user.exception.ErrorCodes;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static tr.com.atez.sign.user.constant.IdentityConstants.KEYCLOAK_ADMIN_CLIENT;
import static tr.com.atez.sign.user.exception.ErrorConstants.ERR_GROUP_NOT_FOUND;
import static tr.com.atez.sign.user.util.UserIdentityUtils.generateKeycloakUserObject;

@Service
public class GroupService {

    private IdentityConfig identityConfig;
    private Keycloak keycloak;

    @Autowired
    public GroupService(IdentityConfig identityConfig, @Qualifier(KEYCLOAK_ADMIN_CLIENT) Keycloak keycloak) {
        this.identityConfig = identityConfig;
        this.keycloak = keycloak;
    }

    public List<Group> getAllGroups() {
        try {
            RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
            GroupsResource groupsResource = realmResource.groups();
            return groupsResource.groups().stream().map(value -> new Group(value.getId(), value.getName())).collect(Collectors.toList());
        } catch (Exception exception) {
            throw new SignException(ErrorCodes.GROUP_NOT_FOUND, exception.getMessage());
        }
    }

    public Group findGroupById(String groupId) {
        try {
            RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
            GroupsResource groupsResource = realmResource.groups();
            GroupRepresentation groupRepresentation = groupsResource.group(groupId).toRepresentation();

            if (ObjectUtils.isNotEmpty(groupRepresentation)) {
                return Group.builder()
                        .id(groupRepresentation.getId())
                        .name(groupRepresentation.getName())
                        .build();
            } else {
                throw new SignException(ErrorCodes.GROUP_NOT_FOUND, ERR_GROUP_NOT_FOUND);
            }
        } catch (Exception exception) {
            throw new SignException(ErrorCodes.GROUP_NOT_FOUND, exception.getMessage());
        }
    }

    public Group createGroup(String groupName) {
        try {
            RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
            GroupsResource groupsResource = realmResource.groups();
            GroupRepresentation groupRepresentation = new GroupRepresentation();
            groupRepresentation.setName(groupName);
            groupsResource.add(groupRepresentation);

            return groupsResource.groups().stream()
                    .filter(item -> groupName.equals(item.getName()))
                    .map(value -> new Group(value.getId(), value.getName()))
                    .findFirst().orElse(null);
        } catch (Exception exception) {
            throw new SignException(ErrorCodes.GROUP_NOT_CREATED, exception.getMessage());
        }
    }

    public List<KeycloakUser> getGroupMembers(String groupName) {
        try {
            RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
            GroupsResource groupsResource = realmResource.groups();
            List<UserRepresentation> userRepresentationList = groupsResource.group(groupName).members();

            List<KeycloakUser> keycloakUserList = new ArrayList<>();
            if (!userRepresentationList.isEmpty()) {
                keycloakUserList = userRepresentationList.stream().map(value -> generateKeycloakUserObject(value.getId(), value)).collect(Collectors.toList());
            }
            return keycloakUserList;
        } catch (Exception exception) {
            throw new SignException(ErrorCodes.GROUP_NOT_FOUND, exception.getMessage());
        }
    }

    public Group updateGroup(String groupId, String groupName) {
        try {
            RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
            GroupsResource groupsResource = realmResource.groups();
            GroupResource groupResource = groupsResource.group(groupId);
            GroupRepresentation groupRepresentation = groupResource.toRepresentation();
            groupRepresentation.setName(groupName);
            groupResource.update(groupRepresentation);

            return groupsResource.groups().stream()
                    .filter(item -> groupName.equals(item.getName()))
                    .map(value -> new Group(value.getId(), value.getName()))
                    .findFirst().orElse(null);
        } catch (Exception exception) {
            throw new SignException(ErrorCodes.GROUP_NOT_UPDATED, exception.getMessage());
        }
    }

    public boolean deleteGroup(String groupId) {
        RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
        GroupResource groupResource = realmResource.groups().group(groupId);
        try {
            groupResource.remove();
        } catch (Exception exception) {
            throw new SignException(ErrorCodes.GROUP_NOT_DELETED, exception.getMessage());
        }
        return true;
    }

    public JoinLeaveGroup joinGroup(JoinLeaveGroup joinGroup) {
        try {
            RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
            UsersResource usersResource = realmResource.users();
            UserResource existingUserResource = usersResource.get(joinGroup.getKeycloakUserId());
            for (Group group : joinGroup.getGroups()) {
                existingUserResource.joinGroup(group.getId());
            }
            return getUpdatedGroupsFromUser(usersResource, joinGroup);
        } catch (Exception exception) {
            throw new SignException(ErrorCodes.GROUP_NOT_UPDATED, exception.getMessage());
        }
    }

    public JoinLeaveGroup leaveGroup(JoinLeaveGroup leaveGroup) {
        try {
            RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
            UsersResource usersResource = realmResource.users();
            UserResource existingUserResource = usersResource.get(leaveGroup.getKeycloakUserId());
            for (Group group : leaveGroup.getGroups()) {
                existingUserResource.leaveGroup(group.getId());
            }

            return getUpdatedGroupsFromUser(usersResource, leaveGroup);
        } catch (Exception exception) {
            throw new SignException(ErrorCodes.GROUP_NOT_UPDATED, exception.getMessage());
        }
    }







    private JoinLeaveGroup getUpdatedGroupsFromUser(UsersResource usersResource, JoinLeaveGroup joinLeaveGroup) {
        UserResource updatedUserResource = usersResource.get(joinLeaveGroup.getKeycloakUserId());
        List<GroupRepresentation> groupRepresentationList = updatedUserResource.groups();
        if (!groupRepresentationList.isEmpty()) {
            List<Group> updatedGroupList = groupRepresentationList.stream().map(value -> new Group(value.getId(), value.getName())).collect(Collectors.toList());
            joinLeaveGroup.getGroups().clear();
            joinLeaveGroup.getGroups().addAll(updatedGroupList);
        }
        return joinLeaveGroup;
    }
}




