package tr.com.atez.sign.user.adapter.base;

import java.util.List;


public interface BaseAdapter<DomainObject, Filter> {

    List<DomainObject> getAll();

    void deleteById(String id);

    List<DomainObject> getAllByIds(List<String> ids);

	Class<DomainObject> forClass();
	
	DomainObject findById(String id);
	
	DomainObject saveOrUpdate(DomainObject DomainObject);


}
