package tr.com.atez.sign.user.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import org.keycloak.admin.client.CreatedResponseUtil;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import tr.com.atez.sign.common.exception.SignException;
import tr.com.atez.sign.common.http.SignHttpClient;
import tr.com.atez.sign.user.config.IdentityConfig;
import tr.com.atez.sign.user.constant.IdentityConstants;
import tr.com.atez.sign.user.domain.AuthResponse;
import tr.com.atez.sign.user.domain.KeycloakUser;
import tr.com.atez.sign.user.dto.UserDTO;
import tr.com.atez.sign.user.exception.ErrorCodes;

import javax.ws.rs.core.Response;
import java.time.LocalDateTime;
import java.util.*;

import static tr.com.atez.sign.common.http.SignHttpUtils.OBJECT_MAPPER;

@Slf4j
@Component
public class UserIdentityUtils {

    private IdentityConfig config;

    @Autowired
    public UserIdentityUtils(IdentityConfig config) {
        this.config = config;
    }

    public AuthResponse calculateExpireDate(AuthResponse authResponse) {
        authResponse.setExpireDate(LocalDateTime.now().plusSeconds(authResponse.getExpires_in()));
        authResponse.setRefreshExpireDate(LocalDateTime.now().plusSeconds(authResponse.getRefresh_expires_in()));
        return authResponse;
    }

    public String getAccountServiceTokenUrl() {
        return config.getUrl() + IdentityConstants.ACCOUNT_SERVICE_TOKEN_URL;
    }

    public Map<String, String> getLoginFormData(String username, String password) {
        return Map.of(IdentityConstants.KEYCLOAK_GRANT_TYPE, IdentityConstants.PASSWORD,
                IdentityConstants.KEYCLOAK_CLIENT_ID, config.getClientId(),
                IdentityConstants.KEYCLOAK_CLIENT_SECRET, config.getClientSecret(),
                IdentityConstants.USERNAME, username,
                IdentityConstants.PASSWORD, password,
                IdentityConstants.SCOPE, IdentityConstants.OPENID
        );
    }

    public Map<String, String> getRefreshTokenFormData(String refreshToken) {
        return Map.of(IdentityConstants.KEYCLOAK_GRANT_TYPE, IdentityConstants.REFRESH_TOKEN,
                IdentityConstants.KEYCLOAK_CLIENT_ID, config.getClientId(),
                IdentityConstants.KEYCLOAK_CLIENT_SECRET, config.getClientSecret(),
                IdentityConstants.REFRESH_TOKEN, refreshToken
        );
    }

    public static KeycloakUser generateKeycloakUserObject(String keycloakUserId, UserRepresentation userRepresentation){
        KeycloakUser keycloakUser = new KeycloakUser();
        try{
           keycloakUser.setId(keycloakUserId);
           keycloakUser.setUsername(userRepresentation.getUsername());
           keycloakUser.setEmail(userRepresentation.getEmail());
           keycloakUser.setFirstName(userRepresentation.getFirstName());
           keycloakUser.setLastName(userRepresentation.getLastName());
           if (userRepresentation.getAttributes() != null && !userRepresentation.getAttributes().isEmpty()) {
               keycloakUser.setAttributes(new HashMap<>());
               keycloakUser.getAttributes().put(IdentityConstants.USER_ID, userRepresentation.getAttributes().get(IdentityConstants.USER_ID).stream().filter(Objects::nonNull).findFirst().get());

           }
       }catch (Exception exception){
            exception.printStackTrace();
       }
        return keycloakUser;
    }

    public static UserRepresentation generateUserRepresentationObject(UserDTO user) throws JsonProcessingException {
        UserRepresentation userRepresentation = new UserRepresentation();
        userRepresentation.setUsername(user.getUsername());
        userRepresentation.setEmail(user.getEmail());
        userRepresentation.setEnabled(Boolean.TRUE);
        userRepresentation.setEmailVerified(Boolean.TRUE);
        userRepresentation.setFirstName(user.getFirstname());
        userRepresentation.setLastName(user.getLastname());
        userRepresentation.setAttributes(new HashMap<>());
        userRepresentation.getAttributes().put(IdentityConstants.USER_ID, Collections.singletonList(user.getId()));
        List<CredentialRepresentation> credentials = new ArrayList<>();
        CredentialRepresentation credentialRepresentation = new CredentialRepresentation();
        credentialRepresentation.setType(CredentialRepresentation.PASSWORD);
        credentialRepresentation.setValue(user.getPassword());
        credentialRepresentation.setTemporary(false);
        credentials.add(credentialRepresentation);
        userRepresentation.setCredentials(credentials);
        return userRepresentation;
    }

    public static UserRepresentation generateUserRepresentationUpdateObject(KeycloakUser keycloakUser, Map<String, List<String>> existingAttributes) throws JsonProcessingException {
        UserRepresentation userRepresentationUpdate = new UserRepresentation();
        userRepresentationUpdate.setId(keycloakUser.getId());
        userRepresentationUpdate.setUsername(keycloakUser.getUsername());
        userRepresentationUpdate.setEmail(keycloakUser.getEmail());
        userRepresentationUpdate.setEnabled(keycloakUser.getEnabled());
        userRepresentationUpdate.setEmailVerified(keycloakUser.getEmailVerified());
        userRepresentationUpdate.setFirstName(keycloakUser.getFirstName());
        userRepresentationUpdate.setLastName(keycloakUser.getLastName());
        if (keycloakUser.getAttributes() != null && !keycloakUser.getAttributes().isEmpty()) {
            for (Map.Entry<String, Object> attribute : keycloakUser.getAttributes().entrySet()) {
                existingAttributes.put(attribute.getKey(), Collections.singletonList(OBJECT_MAPPER.writeValueAsString(attribute.getValue())));
            }
        }
        userRepresentationUpdate.setAttributes(existingAttributes);
        return userRepresentationUpdate;
    }

    public static String validateUserCreationResponse(Response response) {
        if (response.getStatus() == 201) {
            try {
                return CreatedResponseUtil.getCreatedId(response);
            } catch (Exception exception) {
                throw new SignException(ErrorCodes.USER_NOT_CREATED, exception.getMessage());
            }
        } else if (response.getStatus() == 409) {
            throw new SignException(ErrorCodes.USER_ALREADY_CREATED);
        } else {
            throw new SignException(ErrorCodes.SYSTEM_FAILURE);
        }
    }
}
