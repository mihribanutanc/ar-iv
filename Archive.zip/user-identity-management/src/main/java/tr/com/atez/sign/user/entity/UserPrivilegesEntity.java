package tr.com.atez.sign.user.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import javax.persistence.*;

/**
 * @author Abdulkerim ATİK
 */

@SQLDelete(sql = "UPDATE UserPrivileges SET DELETED_AT = CURRENT_TIMESTAMP WHERE id =? and version =? ")
@Where(clause = "DELETED_DATE is null")
@Entity(name = "UserPrivileges")
@Table(name = "USER_PRIVILEGES")
@Data
@EqualsAndHashCode(callSuper = false)
@ToString(callSuper = true, includeFieldNames = true)
public class UserPrivilegesEntity extends  BaseEntity{

    @ManyToOne
    @JoinColumn(name = "PRIVILEGE_ID")
    private PrivilegesEntity privilege;

    @Column(name = "USER_ID")
    private String userId;

    @Column(name = "UNIT_CODE")
    private String unitType;

    @Column(name = "UNIT_ID")
    private String unitId;
}
