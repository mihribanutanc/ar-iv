package tr.com.atez.sign.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;
import tr.com.atez.sign.common.model.SignResponse;
import tr.com.atez.sign.common.util.generator.SignGenerator;
import tr.com.atez.sign.security.model.SignContextHolder;
import tr.com.atez.sign.user.api.UserAPI;
import tr.com.atez.sign.user.domain.KeycloakUser;
import tr.com.atez.sign.user.dto.PasswordDTO;
import tr.com.atez.sign.user.dto.UserDTO;
import tr.com.atez.sign.user.service.UserService;

import javax.validation.Valid;

/**
 * @author Abdulkerim ATİK
 */
@RestController
public class UserController implements UserAPI {

    private UserService userService;

    @Autowired
    public UserController(UserService keyCloakService) {
        this.userService = keyCloakService;
    }

    @Override
    public SignResponse<Object> getUser(String keycloakUserId) {
        return SignGenerator.generateSignResponse(userService.getUser(keycloakUserId));
    }

    @Override
    public SignResponse<Object> createUser(UserDTO userDTO) {
        return SignGenerator.generateSignResponse(userService.createUser(userDTO));
    }

    @Override
    public SignResponse<Object> updateUser(KeycloakUser keycloakUser) {
        return SignGenerator.generateSignResponse(userService.updateUser(keycloakUser));
    }

    @Override
    public SignResponse<Object> updatePassword(String keycloakUserId, PasswordDTO password) {
        return SignGenerator.generateSignResponse(userService.updatePassword(keycloakUserId, password));
    }

    @Override
    public SignResponse<Object> resetPassword(String keycloakUserId, PasswordDTO password) {
        return SignGenerator.generateSignResponse(userService.resetPassword(keycloakUserId, password));
    }

    @Override
    public SignResponse<Boolean> checkIfUserNameExists(String userName) {
        return SignGenerator.generateSignResponse(userService.checkIfUserNameExists(userName));
    }
}
