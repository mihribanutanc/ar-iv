package tr.com.atez.sign.user.specification.base;

import org.springframework.data.jpa.domain.Specification;

public abstract class BaseFilterSpecification<Entity, Filter> extends BaseSpecification {

	public abstract Specification<Entity> filter(Filter filter);
}
