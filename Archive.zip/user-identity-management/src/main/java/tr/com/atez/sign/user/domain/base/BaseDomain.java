package tr.com.atez.sign.user.domain.base;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class BaseDomain implements Serializable {

	private String id;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;
	private Long version = 0L;
	private String createUser;
	private String modifyUser;

}
