package tr.com.atez.sign.user.dto;

import lombok.Data;
import tr.com.atez.sign.user.enums.ActivePassive;

/**
 * @author Abdulkerim ATİK
 */
@Data
public class AssignUserRoleDTO {

    private String roleId;

    private String userId;

    private ActivePassive activePassive;
}
