package tr.com.atez.sign.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import tr.com.atez.sign.common.model.SignResponse;
import tr.com.atez.sign.common.util.generator.SignGenerator;
import tr.com.atez.sign.user.api.PermissionAPI;
import tr.com.atez.sign.user.service.PermissionService;

@RestController
public class PermissionController implements PermissionAPI {

    private PermissionService permissionService;

    @Autowired
    public PermissionController(PermissionService permissionService) {
        this.permissionService = permissionService;
    }


    @Override
    public SignResponse<Object> getPermissions(String clientName) {
        return  SignGenerator.generateSignResponse(permissionService.getPolicies(clientName));
    }
}
