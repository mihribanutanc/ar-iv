package tr.com.atez.sign.user.domain;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class KeycloakUser {

	private String id;
	private String username;
	private String email;
	private Boolean enabled;
	private Boolean totp;
	private Boolean emailVerified;
	private String firstName;
	private String lastName;
	private String notBefore;
	private Map<String, Object> attributes;
	private List<KeycloakCredential> credentials;
	private List<String> realmRoles;

}
