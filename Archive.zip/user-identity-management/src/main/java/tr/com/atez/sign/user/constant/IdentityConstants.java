package tr.com.atez.sign.user.constant;

import java.io.Serializable;

public class IdentityConstants implements Serializable {

	private static final long serialVersionUID = -7840432181410026391L;

	// KEYCLOAK CONSTANTS
	public static final String REALM_KEY = "realm";
	public static final String CLIENT_KEY = "client";
	public static final String DEPARTMENT_IDS = "departmentIds";
	public static final String DEPARTMENT_ID = "departmentId";
	public static final String USER_ID = "userId";
	public static final String CUSTOMER_ID = "customerId";
	public static final String ACCOUNT_IDS = "accountIds";
	public static final String USER_IDENTIFIER = "userIdentifier";
	public static final String REFRESH_TOKEN = "refresh_token";
	public static final String KEYCLOAK_CLIENT_ID = "client_id";
	public static final String KEYCLOAK_CLIENT_SECRET = "client_secret";
	public static final String KEYCLOAK_GRANT_TYPE = "grant_type";
	public static final String AUTHORIZATION = "Authorization";
	public static final String BEARER = "Bearer";
	public static final String KEYCLOAK_CLIENT_CREDENTIALS = "client_credentials";
	public static final String MOBILE_PHONE_NUMBER = "phoneNumber";
	public static final String PASSWORD = "password";
	public static final String USERNAME = "username";
	public static final String SCOPE = "scope";
	public static final String OPENID = "openid";
	public static final String ACCOUNT_ID = "accountId";
	public static final String PORTAL_MANAGER = "portalAdmin";
	public static final String ACCOUNT_UNIT_TYPE = "ACCOUNT";
	public static final String DEPARTMENT_UNIT_TYPE = "DEPARTMENT";
	//Keycloak Server Urls
	public static final String ACCOUNT_SERVICE_USER_URL = "/auth/admin/realms/sign/users";
	public static final String ACCOUNT_SERVICE_TOKEN_URL = "/auth/realms/sign/protocol/openid-connect/token";
	public static final String LOGOUT_URL = "/auth/admin/realms/sign/users/%s/logout";
	public static final String GET_USER_URL = "/auth/admin/realms/sign/users/%s";


	/* Utils */
	public static final String KEYCLOAK_ADMIN_CLIENT = "keycloakAdminClient";
	public static final String COMMERCIAL_NAME="commercialName";

	
}
