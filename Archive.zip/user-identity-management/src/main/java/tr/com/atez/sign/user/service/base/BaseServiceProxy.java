package tr.com.atez.sign.user.service.base;


import tr.com.atez.sign.user.adapter.base.BaseAdapter;

public abstract class BaseServiceProxy<Entity, Filter, Adapter extends BaseAdapter<Entity, Filter>>{

    public abstract Adapter getAdapter();
}
