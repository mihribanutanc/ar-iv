package tr.com.atez.sign.user.service.base;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import tr.com.atez.sign.user.adapter.base.BaseAdapter;
import tr.com.atez.sign.user.filter.base.BaseFilter;

import javax.transaction.Transactional;
import java.util.List;


public abstract class BaseService<DomainObject, Filter extends BaseFilter> extends BaseServiceProxy<DomainObject, Filter, BaseAdapter<DomainObject, Filter>> {

    protected final Logger log = LoggerFactory.getLogger(getClass());

    public List<DomainObject> getAll() {
        return getAdapter().getAll();
    }

    public DomainObject get(String id) {
        return getAdapter().findById(id);
    }

    @Transactional
    public DomainObject save(DomainObject domainObject)  {
        return getAdapter().saveOrUpdate(domainObject);
    }

    public void delete(String id) {
        getAdapter().deleteById(id);
    }

    public List<DomainObject> getAllByIds(List<String> ids) {
        return getAdapter().getAllByIds(ids);
    }

}
