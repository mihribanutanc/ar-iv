package tr.com.atez.sign.user.domain;

import lombok.Data;
import tr.com.atez.sign.user.domain.base.BaseDomain;
import tr.com.atez.sign.user.entity.RolePrivilegesEntity;
import tr.com.atez.sign.user.enums.ActivePassive;

import java.util.List;

/**
 * @author Abdulkerim ATİK
 */
@Data
public class Role extends BaseDomain {

    private String code;

    private ActivePassive status;

    private List<String> privileges;

    private Boolean isAssignable;

    private List<Privileges> rolePrivileges;

}
