package tr.com.atez.sign.user.enums;

import lombok.Getter;

public enum ActivePassive {

    ACTIVE(1,"ActivePassive.ACTIVE"),
    PASSIVE(0,"ActivePassive.PASSIVE");

    ActivePassive(Integer code, String langKey) {
        this.code = code;
        this.langKey = langKey;
    }

    @Getter
    private Integer code;

    @Getter
    private String langKey;

    }
