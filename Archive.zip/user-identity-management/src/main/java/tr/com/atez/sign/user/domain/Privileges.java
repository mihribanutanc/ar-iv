package tr.com.atez.sign.user.domain;


import lombok.Data;
import tr.com.atez.sign.user.domain.base.BaseDomain;
import tr.com.atez.sign.user.enums.ActivePassive;


@Data
public class Privileges extends BaseDomain {

    private String code;

    private String description;

    private ActivePassive status;

    private Boolean isAssignable;

}
