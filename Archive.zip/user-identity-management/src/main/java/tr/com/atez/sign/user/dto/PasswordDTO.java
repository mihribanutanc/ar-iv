package tr.com.atez.sign.user.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PasswordDTO {
    @NotNull
    @NotEmpty
    private String password;
    private boolean isTemporary = false;
}
