package tr.com.atez.sign.user.mapper.dto;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import tr.com.atez.sign.user.domain.Role;
import tr.com.atez.sign.user.domain.UserRole;
import tr.com.atez.sign.user.dto.RoleDTO;
import tr.com.atez.sign.user.dto.UserRoleDTO;
import tr.com.atez.sign.user.mapper.dto.base.BaseDTOMapper;

/**
 * @author Abdulkerim ATİK
 */
@Mapper(componentModel = "spring")
public interface RoleDTOMapper extends BaseDTOMapper<Role, RoleDTO> {


}
