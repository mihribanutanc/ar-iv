package tr.com.atez.sign.user.domain;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class KeyCloakRole {
    private String name;
    private String label;
    private String type;
}
