package tr.com.atez.sign.user.dto;

import lombok.Data;

/**
 * @author Abdulkerim ATİK
 */
@Data
public class LoginDTO {

    private String username;

    private String password;
}
