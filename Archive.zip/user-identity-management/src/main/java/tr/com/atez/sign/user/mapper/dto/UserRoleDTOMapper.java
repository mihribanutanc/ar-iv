package tr.com.atez.sign.user.mapper.dto;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import tr.com.atez.sign.user.domain.Role;
import tr.com.atez.sign.user.domain.UserRole;
import tr.com.atez.sign.user.dto.UserRoleDTO;
import tr.com.atez.sign.user.entity.RoleEntity;
import tr.com.atez.sign.user.mapper.domain.base.BaseMapper;
import tr.com.atez.sign.user.mapper.dto.base.BaseDTOMapper;

/**
 * @author Abdulkerim ATİK
 */
@Mapper(componentModel = "spring")
public interface UserRoleDTOMapper extends BaseDTOMapper<UserRole, UserRoleDTO> {

    @Mapping(source = "role.code",target = "roleName")
    @Mapping(source = "role.id",target = "roleId")
    UserRoleDTO toDTO(UserRole domainObject);

}
