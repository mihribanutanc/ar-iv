package tr.com.atez.sign.user.service;

import lombok.extern.slf4j.Slf4j;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import tr.com.atez.sign.common.exception.SignException;
import tr.com.atez.sign.common.http.SignHttpClient;
import tr.com.atez.sign.security.model.SignContextHolder;
import tr.com.atez.sign.user.config.IdentityConfig;
import tr.com.atez.sign.user.domain.AuthResponse;
import tr.com.atez.sign.user.exception.ErrorCodes;
import tr.com.atez.sign.user.util.UserIdentityUtils;

import java.util.Map;

import static tr.com.atez.sign.common.http.SignHttpUtils.generateHttpDefaultHeaderWithContentType;
import static tr.com.atez.sign.user.constant.IdentityConstants.KEYCLOAK_ADMIN_CLIENT;

/**
 * @author Abdulkerim ATİK
 */
@Slf4j
@Service
public class AuthService {

    private IdentityConfig identityConfig;
    private Keycloak keycloak;
    private SignHttpClient signHttpClient;
    private UserIdentityUtils userIdentityUtils;

    @Autowired
    public AuthService(IdentityConfig identityConfig, @Qualifier(KEYCLOAK_ADMIN_CLIENT) Keycloak keycloak, SignHttpClient signHttpClient, UserIdentityUtils userIdentityUtils) {
        this.identityConfig = identityConfig;
        this.keycloak = keycloak;
        this.signHttpClient = signHttpClient;
        this.userIdentityUtils = userIdentityUtils;
    }

    public AuthResponse login(String username, String password) {
        try {
            Map<String, String> formDataMap = userIdentityUtils.getLoginFormData(username, password);
            AuthResponse authResponse = signHttpClient.doPost(userIdentityUtils.getAccountServiceTokenUrl(),
                    generateHttpDefaultHeaderWithContentType(MediaType.APPLICATION_FORM_URLENCODED_VALUE),
                    formDataMap,
                    AuthResponse.class);
            return userIdentityUtils.calculateExpireDate(authResponse);
        } catch (Exception e) {
            throw new SignException(ErrorCodes.AUTHENTICATION_FAILED,e);
        }
    }

    public AuthResponse refreshToken(String refreshToken) {
        try {
            Map<String, String> formDataMap = userIdentityUtils.getRefreshTokenFormData(refreshToken);
            AuthResponse authResponse = signHttpClient.doPost(userIdentityUtils.getAccountServiceTokenUrl(),
                    generateHttpDefaultHeaderWithContentType(MediaType.APPLICATION_FORM_URLENCODED_VALUE),
                    formDataMap,
                    AuthResponse.class);
            return userIdentityUtils.calculateExpireDate(authResponse);
        } catch (Exception e) {
            throw new SignException(ErrorCodes.SYSTEM_FAILURE, e);
        }
    }

    public boolean logout() {
        try {
            RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
            realmResource.users().get(SignContextHolder.get().getUser().getId()).logout();
            return true;
        } catch (Exception e) {
            throw new SignException(ErrorCodes.SYSTEM_FAILURE, e);
        }
    }
}
