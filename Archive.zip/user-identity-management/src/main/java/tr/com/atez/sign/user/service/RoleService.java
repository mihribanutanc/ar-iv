package tr.com.atez.sign.user.service;

import org.springframework.stereotype.Service;
import tr.com.atez.sign.common.exception.SignException;
import tr.com.atez.sign.user.adapter.RoleAdapter;
import tr.com.atez.sign.user.domain.Role;
import tr.com.atez.sign.user.exception.ErrorCodes;
import tr.com.atez.sign.user.filter.RoleFilter;
import tr.com.atez.sign.user.service.base.BaseService;

import java.util.List;

/**
 * @author Abdulkerim ATİK
 */
@Service
public class RoleService extends BaseService<Role, RoleFilter> {

    private RoleAdapter roleAdapter;

    public RoleService(RoleAdapter roleAdapter) {
        this.roleAdapter = roleAdapter;
    }

    @Override
    public RoleAdapter getAdapter() {
        return roleAdapter;
    }

    public Role findByCode(String code) {
        return getAdapter().findByCode(code).orElseThrow(() -> new SignException(ErrorCodes.ROLE_NOT_FOUND_IN_SYSTEM));
    }

    public List<Role> findAll() {
        return getAdapter().findByIsAssignable(Boolean.TRUE);
    }
}
