package tr.com.atez.sign.user.dto;

import lombok.Data;
import tr.com.atez.sign.common.annotation.ValidPhoneNumber;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author Abdulkerim ATİK
 */
@Data
public class UserDTO {

    private String id;

    private String keycloakId;

    private String username;

    private String identifier;

    @NotNull
    private String password;

    @NotNull
    @Email
    private String email;

    private String firstname;

    private String lastname;

    @ValidPhoneNumber
    private String phoneNumber;

    private String customerId;

    private String departmentId;

    private List<String> departmentIds;

    private String accountId;

}
