package tr.com.atez.sign.user.domain;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class AuthResponse implements Serializable {

	private static final long serialVersionUID = -2756799499290445851L;

	private String access_token;
    private Integer expires_in;
    private String refresh_token;
    private Integer refresh_expires_in;
    private String id_token;
    private LocalDateTime expireDate;
    private LocalDateTime refreshExpireDate;



}
