package tr.com.atez.sign.user.controller;

import org.springframework.web.bind.annotation.RestController;
import tr.com.atez.sign.common.model.SignResponse;
import tr.com.atez.sign.common.util.generator.SignGenerator;
import tr.com.atez.sign.user.api.RolesAPI;
import tr.com.atez.sign.user.dto.RoleDTO;
import tr.com.atez.sign.user.manager.DataReferenceManager;
import tr.com.atez.sign.user.mapper.dto.RoleDTOMapper;
import tr.com.atez.sign.user.service.RoleService;

import java.util.List;

/**
 * @author Abdulkerim ATİK
 */
@RestController
public class RolesController implements RolesAPI {

    DataReferenceManager dataReferenceManager;

    RoleService roleService;

    RoleDTOMapper roleDTOMapper;

    public RolesController(DataReferenceManager dataReferenceManager, RoleService roleService, RoleDTOMapper roleDTOMapper) {
        this.dataReferenceManager = dataReferenceManager;
        this.roleService = roleService;
        this.roleDTOMapper = roleDTOMapper;
    }

    @Override
    public SignResponse<Object> getRoles() {
        List<RoleDTO> roles = roleDTOMapper.toListDTO(roleService.findAll());
        dataReferenceManager.fillRoleDesc(roles);
        return SignGenerator.generateSignResponse(roles);
    }

    @Override
    public SignResponse<Object> getRoleLookup() {
        List<RoleDTO> roles = roleDTOMapper.toListDTO(roleService.findAll());
        return SignGenerator.generateSignResponse(dataReferenceManager.convertSelectItem(roles));

    }
}
