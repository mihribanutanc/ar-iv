package tr.com.atez.sign.user.specification.base;


public class BaseSpecification {

}