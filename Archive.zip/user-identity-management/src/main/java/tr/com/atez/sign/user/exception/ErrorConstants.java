package tr.com.atez.sign.user.exception;

public class ErrorConstants {

    public static final String ERR_CLIENT_NOT_FOUND = "Client not found!";
    public static final String ERR_GROUP_NOT_FOUND = "Group not found! Please check group name!";

    private ErrorConstants(){}
}
