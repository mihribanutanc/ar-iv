package tr.com.atez.sign.user.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;
import tr.com.atez.sign.common.exception.ErrorCode;

import java.util.Arrays;

public enum ErrorCodes implements ErrorCode {

	SYSTEM_FAILURE(-1,"ErrorCodes.SYSTEM_FAILURE", HttpStatus.INTERNAL_SERVER_ERROR),
	AUTHENTICATION_FAILED(-1,"ErrorCodes.AUTHENTICATION_FAILED", HttpStatus.UNAUTHORIZED),
	USER_NOT_FOUND(100,"ErrorCodes.USER_NOT_FOUND", HttpStatus.BAD_REQUEST),
	ACCOUNT_NOT_FOUND(100,"ErrorCodes.ACCOUNT_NOT_FOUND", HttpStatus.BAD_REQUEST),
	ADDRESS_NOT_FOUND(100,"ErrorCodes.ADDRESS_NOT_FOUND", HttpStatus.BAD_REQUEST),
	DEPARTMENT_NOT_FOUND(100,"ErrorCodes.DEPARTMENT_NOT_FOUND", HttpStatus.BAD_REQUEST),
	CUSTOMER_NOT_VALID(100,"ErrorCodes.FIRSTNAME_NOT_VALID", HttpStatus.BAD_REQUEST),
	USER_NOT_UNIQNUESS(100,"ErrorCodes.USER_NOT_UNIQNUESS", HttpStatus.BAD_REQUEST),
	ASSIGNED_USER_HAVE_IN_DEPARTMENT(100,"ErrorCodes.USER_NOT_CREATED", HttpStatus.BAD_REQUEST),
	USER_NOT_CREATED(100,"ErrorCodes.USER_NOT_FOUND", HttpStatus.BAD_REQUEST),
	USER_NOT_UPDATED(100,"ErrorCodes.USER_NOT_UPDATED", HttpStatus.BAD_REQUEST),
	USER_ALREADY_CREATED(409,"ErrorCodes.USER_ALREADY_CREATED", HttpStatus.CONFLICT),
	CLIENT_NOT_FOUND(100,"ErrorCodes.CLIENT_NOT_FOUND", HttpStatus.BAD_REQUEST),
	PASSWORD_NOT_RESET(100,"ErrorCodes.PASSWORD_NOT_RESET", HttpStatus.BAD_REQUEST),
	GROUP_NOT_CREATED(100,"ErrorCodes.GROUP_NOT_CREATED", HttpStatus.BAD_REQUEST),
	GROUP_NOT_FOUND(100,"ErrorCodes.GROUP_NOT_FOUND", HttpStatus.BAD_REQUEST),
	GROUP_NOT_UPDATED(100,"ErrorCodes.GROUP_NOT_UPDATED", HttpStatus.BAD_REQUEST),
	GROUP_NOT_DELETED(100,"ErrorCodes.GROUP_NOT_DELETED", HttpStatus.BAD_REQUEST),
	ROLE_NOT_FOUND_IN_SYSTEM(100,"ErrorCodes.ROLE_NOT_FOUND_IN_SYSTEM", HttpStatus.BAD_REQUEST),
	ROLE_ALREADY_ASSIGN_FOR_USER(100,"ErrorCodes.ROLE_ALREADY_ASSIGN_FOR_USER", HttpStatus.BAD_REQUEST);


	ErrorCodes(Integer code, String langKey, HttpStatus httpStatus) {
		this.code = code;
		this.httpStatus = httpStatus;
		this.langKey=langKey;
	}

	@Getter
	private Integer code;
	
	@Getter
	private String langKey;

	@Getter
	private HttpStatus httpStatus;

	/**
	 * @param code
	 * @return
	 */
	public ErrorCodes findByCode(Integer code) {
		return Arrays.asList(ErrorCodes.values()).stream().filter(f -> f.getCode().equals(code)).findFirst().orElse(ErrorCodes.SYSTEM_FAILURE);
	}

	@Override
	public String getName() {
		return this.name();
	}

	@Override
	public String langKey() {
		return this.langKey;
	}
}
