package tr.com.atez.sign.user.controller;

import org.springframework.web.bind.annotation.RestController;
import tr.com.atez.sign.common.model.SignResponse;
import tr.com.atez.sign.common.util.generator.SignGenerator;
import tr.com.atez.sign.redis.SignRedisClient;
import tr.com.atez.sign.security.constant.KeycloakSecurityClientConstants;
import tr.com.atez.sign.security.filter.SignContextFilter;
import tr.com.atez.sign.security.model.SignContextHolder;
import tr.com.atez.sign.user.api.UserRolesAPI;
import tr.com.atez.sign.user.domain.UserRole;
import tr.com.atez.sign.user.dto.AssignUserRoleDTO;
import tr.com.atez.sign.user.dto.UserRoleDTO;
import tr.com.atez.sign.user.manager.DataReferenceManager;
import tr.com.atez.sign.user.mapper.dto.UserRoleDTOMapper;
import tr.com.atez.sign.user.service.UserRoleService;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Abdulkerim ATİK
 */
@RestController
public class UserRolesController implements UserRolesAPI {


    private UserRoleService userRoleService;

    private UserRoleDTOMapper userRoleDTOMapper;

    private DataReferenceManager dataReferenceManager;

    private SignRedisClient redisClient;

    public UserRolesController(UserRoleService userRoleService, UserRoleDTOMapper userRoleDTOMapper, DataReferenceManager dataReferenceManager, SignRedisClient redisClient) {
        this.userRoleService = userRoleService;
        this.userRoleDTOMapper = userRoleDTOMapper;
        this.dataReferenceManager = dataReferenceManager;
        this.redisClient = redisClient;
    }

    @Override
    public SignResponse<Object> getUserRoles() {
        List<UserRoleDTO> userRoleDtos = userRoleDTOMapper.toListDTO(userRoleService.findByUserId(SignContextFilter.getUserId()));
        userRoleDtos.forEach(f -> {
            f.setRoleDesc(dataReferenceManager.fillRoleDesc(f.getRoleName()));
        });
        return SignGenerator.generateSignResponse(userRoleDtos);
    }

    @Override
    public SignResponse<Object> getUserRolesForAuthorization() {
        List<UserRoleDTO> userRoleDtos = userRoleDTOMapper.toListDTO(userRoleService.findByUserId(SignContextFilter.getUserId()));
        userRoleDtos.forEach(f -> {
            f.setRoleDesc(dataReferenceManager.fillRoleDesc(f.getRoleName()));
        });
        return SignGenerator.generateSignResponse(userRoleDtos);
    }

    @Override
    public SignResponse<Object> getUserRoleById(List<String> ids) {
        List<UserRoleDTO> userRoles = new ArrayList<>();
        ids.forEach(f -> {
            UserRole userRole = userRoleService.findByUserIdAndUnitId(f, SignContextHolder.get().getUser().getAccountId());
            if (userRole != null) {
                userRoles.add(userRoleDTOMapper.toDTO(userRole));
            }
        });
        userRoles.forEach(f -> {
            f.setRoleDesc(dataReferenceManager.fillRoleDesc(f.getRoleName()));
        });
        return SignGenerator.generateSignResponse(userRoles);
    }

    @Override
    public SignResponse<Object> assignRole(AssignUserRoleDTO assignRoleDto) {
        userRoleService.assignRole(assignRoleDto.getRoleId(), assignRoleDto.getUserId());
        redisClient.deleteDataFromRedis(KeycloakSecurityClientConstants.USER_ROLE + "_" + assignRoleDto.getUserId(), KeycloakSecurityClientConstants.USER_ROLE);
        return SignGenerator.generateSignResponse(Boolean.TRUE);
    }

    @Override
    public SignResponse<Object> changeRoleStatus(AssignUserRoleDTO assignRoleDto) {
        Boolean result = userRoleService.changeUserRoleStatus(assignRoleDto.getUserId(), assignRoleDto.getActivePassive());
        redisClient.deleteDataFromRedis(KeycloakSecurityClientConstants.USER_ROLE + "_" + assignRoleDto.getUserId(), KeycloakSecurityClientConstants.USER_ROLE);
        return SignGenerator.generateSignResponse(result);
    }


}
