package tr.com.atez.sign.user.service;

import org.springframework.stereotype.Service;
import tr.com.atez.sign.common.exception.SignException;
import tr.com.atez.sign.security.model.SignContextHolder;
import tr.com.atez.sign.user.adapter.UserRoleAdapter;
import tr.com.atez.sign.user.domain.Role;
import tr.com.atez.sign.user.domain.UserRole;
import tr.com.atez.sign.user.enums.ActivePassive;
import tr.com.atez.sign.user.exception.ErrorCodes;
import tr.com.atez.sign.user.filter.UserRoleFilter;
import tr.com.atez.sign.user.service.base.BaseService;

import java.util.List;
import java.util.Optional;

/**
 * @author Abdulkerim ATİK
 */
@Service
public class UserRoleService extends BaseService<UserRole, UserRoleFilter> {

    private UserRoleAdapter userRoleAdapter;

    private RoleService roleService;


    public UserRoleService(UserRoleAdapter userRoleAdapter, RoleService roleService) {
        this.userRoleAdapter = userRoleAdapter;
        this.roleService = roleService;
    }

    @Override
    public UserRoleAdapter getAdapter() {
        return userRoleAdapter;
    }


    public List<UserRole> findByUserId(String userId) {
        return getAdapter().findByUserIdAndActive(userId, ActivePassive.ACTIVE);
    }

    public UserRole createMasterRole(String roleCode, String unitType, String unitId, String userId) {
        Role role = roleService.findByCode(roleCode);
        UserRole userRole = createInitialRole(role, unitType, unitId, userId);
        userRole.setIsMaster(Boolean.TRUE);
        userRole.setRemoveAble(Boolean.FALSE);
        return getAdapter().saveOrUpdate(userRole);
    }

    private UserRole createInitialRole(Role role, String unitType, String unitId, String userId) {
        UserRole userRole = new UserRole();
        userRole.setRole(role);
        userRole.setUserId(userId);
        userRole.setUnitId(unitId);
        userRole.setUnitType(unitType);
        userRole.setActive(ActivePassive.ACTIVE);
        return userRole;
    }


    public UserRole findByUserIdAndUnitIdAndActive(String userId, ActivePassive active){
        return getAdapter().findByUserIdAndUnitIdAndActive(userId, SignContextHolder.get().getUser().getAccountId(), active).orElseThrow(()->new SignException(ErrorCodes.ROLE_NOT_FOUND_IN_SYSTEM));
    }


    public Boolean changeUserRoleStatus(String userId, ActivePassive active) {
        ActivePassive sqlActive = ActivePassive.ACTIVE.equals(active) ? ActivePassive.PASSIVE : ActivePassive.ACTIVE;
        UserRole user = findByUserIdAndUnitIdAndActive(userId, sqlActive);
        user.setActive(active);
        getAdapter().saveOrUpdate(user);
        return Boolean.TRUE;
    }


    public UserRole assignRole(String roleId, String userId) {
        Role role = roleService.get(roleId);
        if (role == null) {
            throw new SignException(ErrorCodes.ROLE_NOT_FOUND_IN_SYSTEM);
        }

        Optional<UserRole> exitsRole = getAdapter().findByUserIdAndUnitIdAndActive(userId, SignContextHolder.get().getUser().getAccountId(), ActivePassive.ACTIVE);
        if (exitsRole.isPresent()) {
            userRoleAdapter.deleteById(exitsRole.get().getId());
        }
        UserRole userRole =  createInitialRole(role, "ACCOUNT", SignContextHolder.get().getUser().getAccountId(), userId);
        userRole.setIsMaster(Boolean.FALSE);
        userRole.setRemoveAble(Boolean.FALSE);
        userRole.setActive(ActivePassive.ACTIVE);
        return getAdapter().saveOrUpdate(userRole);
    }

    public UserRole findByUserIdAndUnitId(String userId, String unitId,ActivePassive status) {
        return getAdapter().findByUserIdAndUnitIdAndActive(userId, unitId, status).orElse(null);
    }

    public UserRole findByUserIdAndUnitId(String userId, String unitId) {
        return getAdapter().findByUserIdAndUnitId(userId, unitId).orElse(null);
    }
}
