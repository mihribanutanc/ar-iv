package tr.com.atez.sign.user.dto;


import lombok.Data;
import tr.com.atez.sign.user.domain.base.BaseDomain;
import tr.com.atez.sign.user.enums.ActivePassive;

import javax.persistence.*;

@Data
public class PrivilegesDTO  {

    private String id;

    private String code;

    private String description;

    private ActivePassive status;
}
