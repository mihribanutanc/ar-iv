package tr.com.atez.sign.user.repository;

import tr.com.atez.sign.user.entity.RoleEntity;
import tr.com.atez.sign.user.repository.base.BaseRepository;

import java.util.List;
import java.util.Optional;

/**
 * @author Abdulkerim ATİK
 */
public interface RoleRepository extends BaseRepository<RoleEntity> {

    Optional<RoleEntity> findByCode(String s);

    List<RoleEntity> findByIsAssignable(Boolean isAssignable);

}
