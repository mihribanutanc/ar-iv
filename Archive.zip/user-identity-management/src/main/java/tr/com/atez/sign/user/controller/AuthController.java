package tr.com.atez.sign.user.controller;

import org.springframework.web.bind.annotation.RestController;
import tr.com.atez.sign.common.model.SignResponse;
import tr.com.atez.sign.common.util.generator.SignGenerator;
import tr.com.atez.sign.redis.SignRedisClient;
import tr.com.atez.sign.security.constant.KeycloakSecurityClientConstants;
import tr.com.atez.sign.security.model.SignContextHolder;
import tr.com.atez.sign.user.api.AuthAPI;
import tr.com.atez.sign.user.dto.LoginDTO;
import tr.com.atez.sign.user.service.AuthService;

/**
 * @author Abdulkerim ATİK
 */
@RestController
public class AuthController implements AuthAPI {

    private AuthService authService;

    private SignRedisClient signRedisClient;

    public AuthController(AuthService authService, SignRedisClient signRedisClient) {
        this.authService = authService;
        this.signRedisClient = signRedisClient;
    }

    @Override
    public SignResponse<Object> token(LoginDTO login) {
        return SignGenerator.generateSignResponse(authService.login(login.getUsername(), login.getPassword()));
    }

    @Override
    public SignResponse<Object> refreshToken(String refreshToken) {
        return SignGenerator.generateSignResponse(authService.refreshToken(refreshToken));
    }

    @Override
    public SignResponse<Object> logout() {
        boolean isLoggedOut = authService.logout();
        signRedisClient.deleteDataFromRedis(SignContextHolder.get().getUser().getUserId(), KeycloakSecurityClientConstants.KEYCLOAK_USER);
        return SignGenerator.generateSignResponse(isLoggedOut);
    }

}
