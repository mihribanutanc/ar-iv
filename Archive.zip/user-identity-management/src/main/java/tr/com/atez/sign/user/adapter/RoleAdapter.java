package tr.com.atez.sign.user.adapter;

import tr.com.atez.sign.user.adapter.base.BaseAdapter;
import tr.com.atez.sign.user.domain.Role;
import tr.com.atez.sign.user.filter.RoleFilter;

import java.util.List;
import java.util.Optional;

public interface RoleAdapter extends BaseAdapter<Role, RoleFilter> {

    Optional<Role> findByCode(String identifier);

    List<Role> findByIsAssignable(Boolean isAssignable);
}
