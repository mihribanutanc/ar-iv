package tr.com.atez.sign.user.dto;

import lombok.Data;
import tr.com.atez.sign.user.enums.ActivePassive;

import java.util.List;

/**
 * @author Abdulkerim ATİK
 */
@Data
public class UserRoleDTO {

    private String id;

    private String roleId;

    private String roleName;

    private String roleDesc;

    private String userId;

    private String unitType;

    private String unitId;

    private Boolean isMaster;

    private Boolean removeAble;

    private List<String> privileges;

    private ActivePassive active;

}
