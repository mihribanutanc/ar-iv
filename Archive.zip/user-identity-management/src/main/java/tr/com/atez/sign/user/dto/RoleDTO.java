package tr.com.atez.sign.user.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import tr.com.atez.sign.user.domain.Privileges;
import tr.com.atez.sign.user.domain.base.BaseDomain;

import java.util.List;

/**
 * @author Abdulkerim ATİK
 */
@Data
public class RoleDTO extends BaseDomain {

    private String code;

    private String description;

    private List<String> privileges;

    private List<PrivilegesDTO> rolePrivileges;
}
