package tr.com.atez.sign.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import tr.com.atez.sign.common.model.SignResponse;
import tr.com.atez.sign.common.util.generator.SignGenerator;
import tr.com.atez.sign.user.api.KeyCloakRoleAPI;
import tr.com.atez.sign.user.service.KeyCloakRoleService;

@RestController
public class KeyCloakRoleController implements KeyCloakRoleAPI {

    private KeyCloakRoleService keyCloakRoleService;

    @Autowired
    public KeyCloakRoleController(KeyCloakRoleService keyCloakRoleService){
        this.keyCloakRoleService = keyCloakRoleService;
    }

    @Override
    public SignResponse<Object> getAllClientRoles() {
        return SignGenerator.generateSignResponse(keyCloakRoleService.getAllClientRoles());
    }

    @Override
    public SignResponse<Object> getAllRealmRoles() {
        return SignGenerator.generateSignResponse(keyCloakRoleService.getAllRealmRoles());
    }
}
