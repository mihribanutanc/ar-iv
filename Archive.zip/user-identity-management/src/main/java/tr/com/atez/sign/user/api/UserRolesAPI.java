package tr.com.atez.sign.user.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import tr.com.atez.sign.common.model.SignResponse;
import tr.com.atez.sign.user.dto.AssignUserRoleDTO;

import javax.validation.Valid;
import java.util.List;

/**
 * @author Abdulkerim ATİK
 */
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping(path = "/user-roles")
@Validated
public interface UserRolesAPI {

    @Tag(name = "UserRoles")
    @Operation(operationId = "getUserRoles", summary = "Get User Roles")
    @GetMapping
    SignResponse<Object> getUserRoles();

    @Tag(name = "UserRoles")
    @Operation(operationId = "getUserRolesForAuthorization", summary = "Get User Roles For Authorization")
    @GetMapping("authorization")
    SignResponse<Object> getUserRolesForAuthorization();

    @Tag(name = "UserRoles")
    @Operation(operationId = "getUserRolesById", summary = "Get User Roles ById")
    @PostMapping("by-ids")
    SignResponse<Object> getUserRoleById(@RequestBody @Valid List<String> ids);

    @Tag(name = "UserRoles")
    @Operation(operationId = "AssignUserRoles", summary = "Assing User Roles")
    @PostMapping
    SignResponse<Object> assignRole(@RequestBody @Valid AssignUserRoleDTO assignRoleDto);

    @Tag(name = "UserRoles")
    @Operation(operationId = "changeRoleStatus", summary = "Change User Roles status")
    @PutMapping
    SignResponse<Object> changeRoleStatus(@RequestBody @Valid AssignUserRoleDTO assignRoleDto);
}
