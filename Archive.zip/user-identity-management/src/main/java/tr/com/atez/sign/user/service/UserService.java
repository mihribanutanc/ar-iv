package tr.com.atez.sign.user.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.HttpClientErrorException;
import tr.com.atez.sign.common.exception.SignException;
import tr.com.atez.sign.user.config.IdentityConfig;
import tr.com.atez.sign.user.constant.IdentityConstants;
import tr.com.atez.sign.user.domain.KeycloakUser;
import tr.com.atez.sign.user.dto.PasswordDTO;
import tr.com.atez.sign.user.dto.UserDTO;
import tr.com.atez.sign.user.exception.ErrorCodes;
import tr.com.atez.sign.user.util.UserIdentityUtils;

import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

import static tr.com.atez.sign.user.util.UserIdentityUtils.*;

//TODO: Roles will be added user creation process
@Slf4j
@Service
public class UserService {

    private IdentityConfig identityConfig;
    private Keycloak keycloak;
    private UserRoleService userRoleService;

    public UserService(IdentityConfig identityConfig, Keycloak keycloak, UserRoleService userRoleService) {
        this.identityConfig = identityConfig;
        this.keycloak = keycloak;
        this.userRoleService = userRoleService;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public KeycloakUser getUser(String keycloakUserId) {
        try {
            RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
            UsersResource usersResource = realmResource.users();
            UserResource userResource = usersResource.get(keycloakUserId);
            UserRepresentation userRepresentation = userResource.toRepresentation();
            return generateKeycloakUserObject(keycloakUserId, userRepresentation);
        } catch (HttpClientErrorException exception) {
            throw new SignException(ErrorCodes.SYSTEM_FAILURE, exception);
        }
    }


    @Transactional
    public KeycloakUser createUser(UserDTO user) {
        try {
            userRoleService.createMasterRole(IdentityConstants.PORTAL_MANAGER, IdentityConstants.ACCOUNT_UNIT_TYPE, user.getAccountId(), user.getId());
            UserRepresentation userRepresentation = generateUserRepresentationObject(user);
            RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
            UsersResource usersResource = realmResource.users();
            Response response = usersResource.create(userRepresentation);
            String keycloakUserId = UserIdentityUtils.validateUserCreationResponse(response);
            return generateKeycloakUserObject(keycloakUserId, userRepresentation);
        } catch (HttpClientErrorException | JsonProcessingException exception) {
            throw new SignException(ErrorCodes.SYSTEM_FAILURE, exception);
        }
    }

    public KeycloakUser updateUser(KeycloakUser keycloakUser) {
        RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
        UsersResource usersResource = realmResource.users();
        UserResource existingUserResource = usersResource.get(keycloakUser.getId());

        UserRepresentation existingUser;
        try {
            existingUser = existingUserResource.toRepresentation();
        } catch (Exception exception) {
            throw new SignException(ErrorCodes.USER_NOT_FOUND, exception.getMessage());
        }


        UserRepresentation userRepresentationUpdate;
        try {
            userRepresentationUpdate = generateUserRepresentationUpdateObject(keycloakUser, existingUser.getAttributes());
            existingUserResource.update(userRepresentationUpdate);
            UserResource updatedUserResource = usersResource.get(keycloakUser.getId());
            return generateKeycloakUserObject(keycloakUser.getId(), updatedUserResource.toRepresentation());
        } catch (Exception exception) {
            throw new SignException(ErrorCodes.USER_NOT_UPDATED, exception.getMessage());
        }

    public boolean resetPassword(String keycloakUserId, PasswordDTO password) {
        return updatePassword(keycloakUserId, password);
    }

    //TODO: Check if path variable id and token sub match for validation
    public boolean updatePassword(String keycloakUserId, PasswordDTO password) {
        try {
            RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
            UsersResource usersResource = realmResource.users();
            UserRepresentation userRepresentation = new UserRepresentation();
            userRepresentation.setId(keycloakUserId);

            List<CredentialRepresentation> credentials = new ArrayList<>();
            CredentialRepresentation credentialRepresentation = new CredentialRepresentation();
            credentialRepresentation.setType(CredentialRepresentation.PASSWORD);
            credentialRepresentation.setValue(password.getPassword());
            credentialRepresentation.setTemporary(false);
            credentials.add(credentialRepresentation);
            userRepresentation.setCredentials(credentials);
            UserResource userResource = usersResource.get(keycloakUserId);
            userResource.update(userRepresentation);
            UserResource updatedUserResource = usersResource.get(keycloakUserId);
            return !ObjectUtils.isEmpty(updatedUserResource);
        } catch (Exception exception) {
            throw new SignException(ErrorCodes.PASSWORD_NOT_RESET, exception.getMessage());
        }
    }

    public boolean checkIfUserNameExists(String userName) {
        RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
        UsersResource usersResource = realmResource.users();

        List<UserRepresentation> userList;
        boolean isExist = false;
        if (StringUtils.isNotEmpty(userName)) {
            userList = usersResource.search(userName);
            if (!userList.isEmpty()) {
                long userCount = userList.stream().filter(item -> userName.equals(item.getUsername())).count();
                isExist = userCount > 0;
            }
        }
        return isExist;
    }

}
