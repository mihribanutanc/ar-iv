package tr.com.atez.sign.user.domain;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class KeycloakCredential {

	private String type;
	private String value;
	private Boolean temporary = Boolean.FALSE;
}
