package tr.com.atez.sign.user.specification;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;
import tr.com.atez.sign.user.entity.RoleEntity;
import tr.com.atez.sign.user.filter.RoleFilter;
import tr.com.atez.sign.user.specification.base.BaseFilterSpecification;

/**
 * @author Abdulkerim ATİK
 */
@Component
public class RoleSpecification extends BaseFilterSpecification<RoleEntity, RoleFilter> {
    @Override
    public Specification<RoleEntity> filter(RoleFilter roleFilter) {
        return null;
    }
}
