package tr.com.atez.sign.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import tr.com.atez.sign.common.model.SignResponse;
import tr.com.atez.sign.common.util.generator.SignGenerator;
import tr.com.atez.sign.user.api.GroupApi;
import tr.com.atez.sign.user.domain.JoinLeaveGroup;
import tr.com.atez.sign.user.service.GroupService;

@RestController
public class GroupController implements GroupApi {

    private GroupService groupService;

    @Autowired
    public GroupController(GroupService groupService) {
        this.groupService = groupService;
    }


    @Override
    public SignResponse<Object> getAllGroups() {
        return SignGenerator.generateSignResponse(groupService.getAllGroups());
    }

    @Override
    public SignResponse<Object> getGroupById(String groupId) {
        return SignGenerator.generateSignResponse(groupService.findGroupById(groupId));
    }

    @Override
    public SignResponse<Object> getGroupMembers(String groupId) {
        return SignGenerator.generateSignResponse(groupService.getGroupMembers(groupId));
    }

    @Override
    public SignResponse<Object> createGroup(String name) {
        return SignGenerator.generateSignResponse(groupService.createGroup(name));
    }

    @Override
    public SignResponse<Object> updateGroup(String groupId, String groupName) {
        return SignGenerator.generateSignResponse(groupService.updateGroup(groupId, groupName));
    }

    @Override
    public SignResponse<Object> deleteGroup(String groupId) {
        return SignGenerator.generateSignResponse(groupService.deleteGroup(groupId));
    }

    @Override
    public SignResponse<Object> joinGroup(JoinLeaveGroup joinGroup) {
        return SignGenerator.generateSignResponse(groupService.joinGroup(joinGroup));
    }

    @Override
    public SignResponse<Object> leaveGroup(JoinLeaveGroup leaveGroup) {
        return SignGenerator.generateSignResponse(groupService.leaveGroup(leaveGroup));
    }
}
