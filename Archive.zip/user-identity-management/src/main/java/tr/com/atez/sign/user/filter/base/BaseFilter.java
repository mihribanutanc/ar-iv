package tr.com.atez.sign.user.filter.base;

import lombok.Data;

import java.util.List;


@Data
public abstract class BaseFilter {

    private Integer pageItemCount;

    private Integer pageNumber;

    private Integer totalItemCount;

    private List<String> sortProperties;

    private String sortType;

}
