package tr.com.atez.sign.user.repository;

import tr.com.atez.sign.user.entity.UserRoleEntity;
import tr.com.atez.sign.user.enums.ActivePassive;
import tr.com.atez.sign.user.repository.base.BaseRepository;

import java.util.List;
import java.util.Optional;

/**
 * @author Abdulkerim ATİK
 */
public interface UserRoleRepository extends BaseRepository<UserRoleEntity> {

    List<UserRoleEntity> findByUserIdAndActive(String userId, ActivePassive active);

    Optional<UserRoleEntity> findByUserIdAndUnitIdAndActive(String userId,String unitId,ActivePassive active);

    Optional<UserRoleEntity> findByUserIdAndUnitId(String userId,String unitId);

}
