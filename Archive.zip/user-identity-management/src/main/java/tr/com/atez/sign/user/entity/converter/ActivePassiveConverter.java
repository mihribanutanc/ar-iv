package tr.com.atez.sign.user.entity.converter;

import tr.com.atez.sign.user.enums.ActivePassive;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.util.stream.Stream;

@Converter(autoApply = true)
public class ActivePassiveConverter implements AttributeConverter<ActivePassive, Integer> {

    @Override
    public Integer convertToDatabaseColumn(ActivePassive articleStatus) {
        if (articleStatus == null) {
            return null;
        }
        return articleStatus.getCode();
    }

    @Override
    public ActivePassive convertToEntityAttribute(Integer id) {
        if (id == null) {
            return null;
        }
        return Stream.of(ActivePassive.values()).filter(c -> c.getCode().equals(id)).findFirst().orElseThrow(IllegalArgumentException::new);
    }

}
