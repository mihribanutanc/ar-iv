package tr.com.atez.sign.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"tr.com.atez"})
public class UserIdentityManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserIdentityManagementApplication.class, args);
	}

}
