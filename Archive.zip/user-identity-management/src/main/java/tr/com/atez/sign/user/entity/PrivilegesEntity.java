package tr.com.atez.sign.user.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;
import tr.com.atez.sign.user.enums.ActivePassive;

import javax.persistence.*;

/**
 * @author Abdulkerim ATİK
 */

@SQLDelete(sql = "UPDATE Privileges SET DELETED_AT = CURRENT_TIMESTAMP WHERE id =? and version =? ")
@Where(clause = "DELETED_DATE is null")
@Entity(name = "Privileges")
@Table(name = "PRIVILEGES", indexes = {@Index(columnList = "code", name = "privileges_code_idx")})
@Data
@EqualsAndHashCode(callSuper = false)
@ToString(callSuper = true, includeFieldNames = true)
public class PrivilegesEntity extends  BaseEntity {

    @Column(name = "CODE")
    private String code;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "STATUS")
    private ActivePassive status;

    @Column(name = "ASSIGNABLE")
    private Boolean isAssignable;

}
