package tr.com.atez.sign.user.specification;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;
import tr.com.atez.sign.user.entity.UserRoleEntity;
import tr.com.atez.sign.user.filter.UserRoleFilter;
import tr.com.atez.sign.user.specification.base.BaseFilterSpecification;

/**
 * @author Abdulkerim ATİK
 */
@Component
public class UserRoleSpecification extends BaseFilterSpecification<UserRoleEntity, UserRoleFilter> {

    @Override
    public Specification<UserRoleEntity> filter(UserRoleFilter userRoleFilter) {
        return null;
    }
}
