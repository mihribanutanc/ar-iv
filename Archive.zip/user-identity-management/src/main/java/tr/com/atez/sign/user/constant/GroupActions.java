package tr.com.atez.sign.user.constant;

import lombok.Getter;

public enum GroupActions {

    JOIN("join"),
    LEAVE("leave");

    GroupActions(String value) {
        this.value= value;
    }

    @Getter
    private String value;
}
