package tr.com.atez.sign.user.adapter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import tr.com.atez.sign.user.adapter.base.BaseAdapterImpl;
import tr.com.atez.sign.user.domain.KeyCloakRole;
import tr.com.atez.sign.user.domain.Role;
import tr.com.atez.sign.user.entity.RoleEntity;
import tr.com.atez.sign.user.filter.RoleFilter;
import tr.com.atez.sign.user.mapper.domain.RoleMapper;
import tr.com.atez.sign.user.repository.RoleRepository;
import tr.com.atez.sign.user.specification.RoleSpecification;

import java.util.List;
import java.util.Optional;

@Component
public class RoleAdapterImpl extends BaseAdapterImpl<RoleEntity, Role, RoleFilter, RoleRepository, RoleMapper, RoleSpecification> implements RoleAdapter {

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private RoleMapper roleMapper;

    @Autowired
    private RoleSpecification roleSpecification;



    @Override
    public RoleRepository getRepository() {
        return roleRepository;
    }

    @Override
    public RoleMapper getMapper() {
        return roleMapper;
    }

    @Override
    protected RoleSpecification getSpecification() {
        return roleSpecification;
    }

    @Override
    public Optional<Role> findByCode(String code) {
        return getRepository().findByCode(code).map(getMapper()::toDomainObject);
    }


    @Override
    public List<Role> findByIsAssignable(Boolean isAssignable){
        return getMapper().toListDomainObject(getRepository().findByIsAssignable(isAssignable));
    }

}
