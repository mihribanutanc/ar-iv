package tr.com.atez.sign.user.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import tr.com.atez.sign.common.model.SignResponse;

/**
 * @author Abdulkerim ATİK
 */
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping(path = "/roles")
@Validated
public interface RolesAPI {

    @Tag(name = "Roles")
    @Operation(operationId = "getRoles", summary = "Get Roles")
    @GetMapping
    SignResponse<Object> getRoles();


    @Tag(name = "Roles")
    @Operation(operationId = "getRoleLookup ", summary = "Get Role Lookup")
    @GetMapping("lookup")
    SignResponse<Object> getRoleLookup();

}
