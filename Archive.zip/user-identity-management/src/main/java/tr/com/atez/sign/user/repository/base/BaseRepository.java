package tr.com.atez.sign.user.repository.base;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.NoRepositoryBean;

import java.util.Collection;

@NoRepositoryBean
public interface BaseRepository<T> extends JpaRepository<T, String>, JpaSpecificationExecutor<T> {

	@Override
	@Query("update #{#entityName} e set e.deletedDate= CURRENT_DATE where e.id = ?1")
	@Modifying
	void deleteById(String id);

	@Query("update #{#entityName} e set e.deletedDate= CURRENT_DATE where e.id IN ?1")
	@Modifying
	void deleteByIds(Collection<Long> names);

}
