package tr.com.atez.sign.user.service;

import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.RolesResource;
import org.keycloak.representations.idm.ClientRepresentation;
import org.keycloak.representations.idm.RoleRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import tr.com.atez.sign.common.exception.SignException;
import tr.com.atez.sign.user.config.IdentityConfig;
import tr.com.atez.sign.user.domain.KeyCloakRole;
import tr.com.atez.sign.user.exception.ErrorCodes;

import java.util.List;
import java.util.stream.Collectors;

import static tr.com.atez.sign.user.constant.IdentityConstants.*;
import static tr.com.atez.sign.user.exception.ErrorConstants.ERR_CLIENT_NOT_FOUND;

//TODO: Permissions rules will be created

@Service
public class KeyCloakRoleService {

    private IdentityConfig identityConfig;
    private Keycloak keycloak;

    @Autowired
    public KeyCloakRoleService(IdentityConfig identityConfig, @Qualifier(KEYCLOAK_ADMIN_CLIENT) Keycloak keycloak) {
        this.identityConfig = identityConfig;
        this.keycloak = keycloak;
    }

    public List<KeyCloakRole> getAllClientRoles() {
        RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
        String clientId = realmResource.clients().findByClientId(identityConfig.getClientId())
                .stream()
                .map(ClientRepresentation::getId)
                .findFirst()
                .orElseThrow(() -> new SignException(ErrorCodes.CLIENT_NOT_FOUND, ERR_CLIENT_NOT_FOUND));
        RolesResource rolesResource = realmResource.clients().get(clientId).roles();
        return rolesResource.list().stream().map(value -> new KeyCloakRole(value.getName(), value.getDescription(), CLIENT_KEY)).collect(Collectors.toList());
    }

    public List<KeyCloakRole> getAllRealmRoles() {
        RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
        List<RoleRepresentation> realmRoleList = realmResource.roles().list();
        return realmRoleList.stream().map(value -> new KeyCloakRole(value.getName(), value.getDescription(), REALM_KEY)).collect(Collectors.toList());
    }
}
