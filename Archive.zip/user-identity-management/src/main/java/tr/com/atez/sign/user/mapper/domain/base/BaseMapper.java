package tr.com.atez.sign.user.mapper.domain.base;

import java.util.List;

public interface BaseMapper<Entity, DomainObject> {

    Entity toEntity(DomainObject domainObject);

    List<DomainObject> toListDomainObject(List<Entity> entities);

    DomainObject toDomainObject(Entity entity);

    List<Entity> toEntityList(List<DomainObject> domainObjects);

}
