package tr.com.atez.sign.user.domain;

import lombok.Data;
import tr.com.atez.sign.user.domain.base.BaseDomain;
import tr.com.atez.sign.user.enums.ActivePassive;

import java.util.List;

/**
 * @author Abdulkerim ATİK
 */
@Data
public class UserRole extends BaseDomain {

    private Role role;

    private String userId;

    private String unitType;

    private String unitId;

    private Boolean isMaster;

    private Boolean removeAble;

    private List<String> privileges;

    private ActivePassive active;

}
