package tr.com.atez.sign.user.mapper.dto.base;

import java.util.List;

public interface BaseDTOMapper<DomainObject, DTO> {

    DomainObject toDomainObject(DTO dto);

    List<DTO> toListDTO(List<DomainObject> domainObjects);

    DTO toDTO(DomainObject domainObject);

    List<DomainObject> toEntityList(List<DTO> dtos);

}
