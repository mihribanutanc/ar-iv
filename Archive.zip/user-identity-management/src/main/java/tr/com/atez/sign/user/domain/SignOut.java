package tr.com.atez.sign.user.domain;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SignOut {
    private String realm;
    private String keycloakUserId;
}
