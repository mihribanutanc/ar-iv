package tr.com.atez.sign.user.config;

import lombok.Getter;
import org.keycloak.OAuth2Constants;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.KeycloakBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import tr.com.atez.sign.common.config.YamlPropertySourceFactory;

import static tr.com.atez.sign.user.constant.IdentityConstants.KEYCLOAK_ADMIN_CLIENT;

/**
 * @author Abdulkerim ATİK
 */

@Configuration
@PropertySource(value = "file:${CONFIG_ROOT}/application.yml", factory = YamlPropertySourceFactory.class,  encoding = "UTF8")
public class IdentityConfig {

    @Getter
    @Value("${atez-signer.keycloak.realm}")
    private String realm;

    @Getter
    @Value("${atez-signer.keycloak.url}")
    private String url;

    @Getter
    @Value("${atez-signer.keycloak.client-id}")
    private String clientId;

    @Getter
    @Value("${atez-signer.keycloak.client-secret}")
    private String clientSecret;

    @Bean(name = {KEYCLOAK_ADMIN_CLIENT})
    @Primary
    public Keycloak keycloakAdminClient() {
        return KeycloakBuilder.builder()
                .serverUrl(this.url+"/auth")
                .grantType(OAuth2Constants.CLIENT_CREDENTIALS)
                .realm(realm)
                .clientId(this.clientId)
                .clientSecret(this.clientSecret)
                .build();
    }
}
