package tr.com.atez.sign.user.adapter.base;

import org.springframework.data.domain.*;
import org.springframework.util.CollectionUtils;
import tr.com.atez.sign.user.filter.base.BaseFilter;
import tr.com.atez.sign.user.mapper.domain.base.BaseMapper;
import tr.com.atez.sign.user.repository.base.BaseRepository;
import tr.com.atez.sign.user.repository.base.BaseRepositoryProxy;
import tr.com.atez.sign.user.specification.base.BaseFilterSpecification;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


public abstract class BaseAdapterImpl<Entity, DomainObject, Filter extends BaseFilter, Repository extends BaseRepository<Entity>, Mapper extends BaseMapper<Entity, DomainObject>, Specification extends BaseFilterSpecification<Entity, Filter>> extends BaseRepositoryProxy<Entity, Filter, Specification> implements BaseAdapter<DomainObject, Filter> {

    public abstract Repository getRepository();

    public abstract Mapper getMapper();

    public DomainObject findById(String id) {
        Optional<Entity> optionalEntity = getRepository().findById(id);
        return optionalEntity.isPresent() ? getMapper().toDomainObject(optionalEntity.get()) : null;
    }

    public List<DomainObject> getAll() {
        return getMapper().toListDomainObject(getRepository().findAll());
    }

    @Transactional
    public List<DomainObject> findAll() {
        return getMapper().toListDomainObject(getRepository().findAll());
    }

    public DomainObject saveOrUpdate(DomainObject domainObject) {
        Entity entity = getRepository().save(getMapper().toEntity(domainObject));
        return getMapper().toDomainObject(entity);
    }

    public void deleteById(String id) {
        getRepository().deleteById(id);
    }

    protected Pageable createPageable(Filter filter) {
        Pageable pageable = PageRequest.of(filter.getPageNumber(), filter.getPageItemCount());
        if (!CollectionUtils.isEmpty(filter.getSortProperties())) {
            String[] properties = filter.getSortProperties().stream().toArray(String[]::new);
            if (Sort.Direction.ASC.name().equals(filter.getSortType())) {
                pageable = PageRequest.of(filter.getPageNumber(), filter.getPageItemCount(), Sort.by(properties).ascending());
            } else {
                pageable = PageRequest.of(filter.getPageNumber(), filter.getPageItemCount(), Sort.by(properties).descending());
            }
        }
        return pageable;
    }

    protected Page<DomainObject> convertToPageDomain(Page<Entity> entityPage) {
        return new PageImpl<DomainObject>(getMapper().toListDomainObject(entityPage.getContent()), entityPage.getPageable(), entityPage.getContent().size());
    }


    @Override
    public List<DomainObject> getAllByIds(List<String> ids) {
        List<Entity> entities = getRepository().findAllById(ids);
        return CollectionUtils.isEmpty(entities) ? new ArrayList<>() : getMapper().toListDomainObject(entities);
    }

    @Override
    public Class<DomainObject> forClass() {
    	return null;
    }

    protected PageRequest createPageRequest(int pageNumber, int pageItemCount, Sort sort) {
        if (sort != null) {
            return PageRequest.of(pageNumber, pageItemCount, sort);
        }
        return PageRequest.of(pageNumber, pageItemCount);
    }


    protected  Sort createSort(String sort, List<String> sortProperties) {
        String[] stringArray = sortProperties.stream().toArray(String[]::new);
        return Sort.by(Sort.Direction.ASC.equals(sort) ? Sort.Direction.ASC : Sort.Direction.DESC,stringArray);

    }
}
