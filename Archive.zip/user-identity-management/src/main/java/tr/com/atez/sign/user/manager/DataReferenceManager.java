package tr.com.atez.sign.user.manager;

import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import tr.com.atez.sign.common.dto.SelectItemDTO;
import tr.com.atez.sign.common.localization.service.MultiLanguageService;
import tr.com.atez.sign.user.dto.RoleDTO;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Abdulkerim ATİK
 */
@Component
public class DataReferenceManager {

    MultiLanguageService multiLanguageService;

    public DataReferenceManager(MultiLanguageService multiLanguageService) {
        this.multiLanguageService = multiLanguageService;
    }

    public void fillRoleDesc(List<RoleDTO> roles) {
        if (CollectionUtils.isEmpty(roles)) {
            return;
        }
        roles.forEach(r -> {
            r.setDescription(fillRoleDesc(r.getCode()));
            r.getRolePrivileges().stream().forEach(p -> {
                p.setDescription(fillPrivilegesDesc(p.getCode()));
            });
        });
    }

    public String fillRoleDesc(String role) {
        return multiLanguageService.getMessage("Role." + role);
    }


    public String fillPrivilegesDesc(String privilegesCode) {
        return multiLanguageService.getMessage("Privileges." + privilegesCode);
    }


    public List<SelectItemDTO> convertSelectItem(List<RoleDTO> roles) {
        if (CollectionUtils.isEmpty(roles)) {
            return List.of();
        }

        List<SelectItemDTO> result = new ArrayList<>();
        roles.forEach(r -> {
            String desc = multiLanguageService.getMessage("Role." + r.getCode());
            result.add(new SelectItemDTO(r.getId(), desc));
        });
        return result;
    }
}
