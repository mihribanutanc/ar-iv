package tr.com.atez.sign.user.filter;

import lombok.Data;
import tr.com.atez.sign.user.filter.base.BaseFilter;

/**
 * @author Abdulkerim ATİK
 */
@Data
public class UserRoleFilter extends BaseFilter {
}
