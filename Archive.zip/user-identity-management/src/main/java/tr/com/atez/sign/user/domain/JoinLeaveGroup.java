package tr.com.atez.sign.user.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class JoinLeaveGroup {
    @NotEmpty
    @NotNull
    private String keycloakUserId;
    @NotEmpty
    @NotNull
    private List<Group> groups;
}
