package tr.com.atez.sign.user.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;
import tr.com.atez.sign.user.enums.ActivePassive;

import javax.persistence.*;

/**
 * @author Abdulkerim ATİK
 */

@SQLDelete(sql = "UPDATE UserRole SET DELETED_AT = CURRENT_TIMESTAMP WHERE id =? and version =? ")
@Where(clause = "DELETED_DATE is null")
@Entity(name = "UserRole")
@Table(name = "USER_ROLE")
@Data
@EqualsAndHashCode(callSuper = false)
@ToString(callSuper = true, includeFieldNames = true)
public class UserRoleEntity extends BaseEntity {

    @ManyToOne
    @JoinColumn(name = "ROLE_ID")
    private RoleEntity role;

    @Column(name = "USER_ID")
    private String userId;

    @Column(name = "UNIT_CODE")
    private String unitType;

    @Column(name = "UNIT_ID")
    private String unitId;

    @Column(name = "IS_MASTER")
    private Boolean isMaster;

    @Column(name = "REMOVE_ABLE")
    private Boolean removeAble;

    @Column(name = "ACTIVE")
    private ActivePassive active;

}
