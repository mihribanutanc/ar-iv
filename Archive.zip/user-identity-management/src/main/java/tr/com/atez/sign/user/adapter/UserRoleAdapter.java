package tr.com.atez.sign.user.adapter;

import tr.com.atez.sign.user.adapter.base.BaseAdapter;
import tr.com.atez.sign.user.domain.UserRole;
import tr.com.atez.sign.user.entity.UserRoleEntity;
import tr.com.atez.sign.user.enums.ActivePassive;
import tr.com.atez.sign.user.filter.UserRoleFilter;

import java.util.List;
import java.util.Optional;

public interface UserRoleAdapter extends BaseAdapter<UserRole, UserRoleFilter> {

    List<UserRole> findByUserIdAndActive(String userId, ActivePassive active);

    Optional<UserRole> findByUserIdAndUnitIdAndActive(String userId, String unitId,ActivePassive active);

    Optional<UserRole> findByUserIdAndUnitId(String userId, String unitId);
}
