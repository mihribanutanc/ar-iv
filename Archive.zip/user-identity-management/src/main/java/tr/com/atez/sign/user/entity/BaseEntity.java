package tr.com.atez.sign.user.entity;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@MappedSuperclass
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@EntityListeners({ AuditingEntityListener.class })
public class BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    private String id;

    @CreationTimestamp
    @Column(name = "CDATE")
    private LocalDateTime createDate;

    @UpdateTimestamp
    @Column(name = "UDATE")
    private LocalDateTime modifyDate;

    @CreatedBy
    @Column(name = "CUSER_ID")
    private String createUserId;

    @LastModifiedBy
    @Column(name = "UUSER_ID")
    private String modifyUserId;

    @NotNull
    @Version
    @Column(name = "VERSION")
    private Long version = 0L;

    @Column(name = "DELETED_DATE")
    private LocalDateTime deletedDate;


}
