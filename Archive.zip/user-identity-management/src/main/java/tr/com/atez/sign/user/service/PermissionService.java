package tr.com.atez.sign.user.service;

import lombok.extern.slf4j.Slf4j;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.ClientResource;
import org.keycloak.admin.client.resource.PoliciesResource;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.representations.idm.authorization.PolicyRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import tr.com.atez.sign.common.exception.SignException;
import tr.com.atez.sign.user.config.IdentityConfig;
import tr.com.atez.sign.user.exception.ErrorCodes;

import java.util.List;

import static tr.com.atez.sign.user.constant.IdentityConstants.KEYCLOAK_ADMIN_CLIENT;

@Slf4j
@Service
public class PermissionService {

    private IdentityConfig identityConfig;
    private Keycloak keycloak;

    @Autowired
    public PermissionService(IdentityConfig identityConfig, @Qualifier(KEYCLOAK_ADMIN_CLIENT) Keycloak keycloak) {
        this.identityConfig = identityConfig;
        this.keycloak = keycloak;
    }

    //TODO: Will be refactored after all policies designed
    public List<PolicyRepresentation> getPolicies(String clientName){
        try {
            RealmResource realmResource = keycloak.realm(identityConfig.getRealm());
            ClientResource clientResource = realmResource.clients().get(clientName);
            PoliciesResource policiesResource = clientResource.authorization().policies();
            return policiesResource.policies();
        } catch (HttpClientErrorException exception) {
            throw new SignException(ErrorCodes.SYSTEM_FAILURE, exception);
        }
    }
}
