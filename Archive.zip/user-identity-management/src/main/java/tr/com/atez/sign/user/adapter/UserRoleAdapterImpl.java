package tr.com.atez.sign.user.adapter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import tr.com.atez.sign.user.adapter.base.BaseAdapterImpl;
import tr.com.atez.sign.user.domain.UserRole;
import tr.com.atez.sign.user.entity.UserRoleEntity;
import tr.com.atez.sign.user.enums.ActivePassive;
import tr.com.atez.sign.user.filter.UserRoleFilter;
import tr.com.atez.sign.user.mapper.domain.UserRoleMapper;
import tr.com.atez.sign.user.repository.UserRoleRepository;
import tr.com.atez.sign.user.specification.UserRoleSpecification;

import java.util.List;
import java.util.Optional;

@Component
public class UserRoleAdapterImpl extends BaseAdapterImpl<UserRoleEntity, UserRole, UserRoleFilter, UserRoleRepository, UserRoleMapper, UserRoleSpecification> implements UserRoleAdapter {

    @Autowired
    private UserRoleRepository userRoleRepository;

    @Autowired
    private UserRoleMapper userRoleMapper;

    @Autowired
    private UserRoleSpecification userRoleSpecification;


    @Override
    public UserRoleRepository getRepository() {
        return userRoleRepository;
    }

    @Override
    public UserRoleMapper getMapper() {
        return userRoleMapper;
    }

    @Override
    protected UserRoleSpecification getSpecification() {
        return userRoleSpecification;
    }

    @Override
    public List<UserRole> findByUserIdAndActive(String userId, ActivePassive active) {
        return getMapper().toListDomainObject(getRepository().findByUserIdAndActive(userId, active));
    }

    @Override
    public Optional<UserRole> findByUserIdAndUnitIdAndActive(String userId, String unitId, ActivePassive active) {
        return getRepository().findByUserIdAndUnitIdAndActive(userId, unitId, active).map(getMapper()::toDomainObject);
    }

    @Override
    public Optional<UserRole> findByUserIdAndUnitId(String userId, String unitId) {
        return getRepository().findByUserIdAndUnitId(userId, unitId).map(getMapper()::toDomainObject);
    }

}
