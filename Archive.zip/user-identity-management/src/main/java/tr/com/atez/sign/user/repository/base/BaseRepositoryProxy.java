package tr.com.atez.sign.user.repository.base;


import tr.com.atez.sign.user.specification.base.BaseFilterSpecification;

public abstract class BaseRepositoryProxy<Entity, Filter, Specification  extends BaseFilterSpecification<Entity, Filter>> {

    protected abstract Specification getSpecification();

}
